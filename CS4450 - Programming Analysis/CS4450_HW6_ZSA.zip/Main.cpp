//Main.cpp
// Name:		Zack Austin
// Date:		9/18/13
// Class:		CS 4450
// Assignment:	Homework 6 Additional Problem
// Purpose:		Learn how to set up a bit field structure and union.

#include <string>
#include <iostream>
#include <stdint.h> 

using namespace std;

const int ARRAYMAXSIZE = 5;

int main()
{
	//Programmer Information:
	cout << "Name:		Zack Austin\n";
	cout << "Date:		9/18/13\n";
	cout << "Class:		CS 4450\n";
	cout << "Assignment:	Homework 6 Additional Problem\n";
	cout << "Purpose:	Learn how to set up a bit field structure and union.\n\n";

	//Input:
	unsigned long long hexArray[ARRAYMAXSIZE];
	hexArray[0] = 0x08800080000004D2;
	hexArray[1] = 0xE05000000000008E;
	hexArray[2] = 0x1140408300000000;
	hexArray[3] = 0x5008000300000000;
	hexArray[4] = 0xE800000000000020;

	//Union and Bit-Field Structure:
	union T
	{
		struct bitField
		{
			unsigned li : 32;
			unsigned rreg : 6;
			unsigned lreg : 6;
			unsigned si : 7;
			unsigned radrm : 4;
			unsigned ladrm : 4;
			unsigned code : 5;
		} bitCode;
		unsigned long long word;
	} bit;

	//Formatted Output:
	for (int i = 0; i < ARRAYMAXSIZE; i++)
	{
		bit.word = hexArray[i];
		cout << "Instruction: " << std::hex << std::uppercase << bit.word << "\n";
		cout << "rreg = " << std::dec << int(bit.bitCode.rreg) << "\n";
		cout << "lreg = " << std::dec << int(bit.bitCode.lreg) << "\n";
		cout << "si = " << std::dec << int(bit.bitCode.si) << "\n";
		cout << "radrm = " << std::dec << (bit.bitCode.radrm) << "\n";
		cout << "ladrm = " << std::dec << int(bit.bitCode.ladrm) << "\n";
		cout << "code = " << std::dec << int(bit.bitCode.code) << "\n";
		cout << "li = " << std::dec << int(bit.bitCode.li) << "\n\n";
	}
	system("Pause");
}