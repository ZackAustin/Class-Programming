class HasConst
{
   const int x;
public:
   HasConst(int y) : x(y) {}
//   HasConst(int y) {x = y;} // Error
};

