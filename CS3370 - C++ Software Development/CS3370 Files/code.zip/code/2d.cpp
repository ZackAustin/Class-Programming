#include <iostream>
using namespace std;

int main()
{
   int *p[4] = new int[3][4];
}
