// bind1.cpp:
#include <algorithm>
#include <functional>
#include <iostream>
#include <iterator>
using namespace std;
using namespace std::placeholders;

int main() {
    int a[] = {1,2,3,4,5};
    auto f = bind(greater<int>(),_1,3);
    transform(a,a+5,a,f);
    cout << boolalpha;
    copy(a,a+5,ostream_iterator<bool>(cout," "));
    cout << endl;
}

/* Output (which positions hold greater than 3?):
false false false true true 
*/