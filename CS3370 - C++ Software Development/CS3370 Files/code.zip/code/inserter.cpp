#include <algorithm>
#include <cstdlib>
#include <functional>
#include <iostream>
#include <iterator>
#include <numeric>
#include <string>
#include <vector>
using namespace std;
using namespace std::placeholders;

void print(const vector<unsigned int>& v) {
    copy(begin(v), end(v), ostream_iterator<unsigned int>(cout, " "));
    cout << endl;
}

int main() {
    vector<unsigned int> v1;
    generate_n(back_inserter(v1), 10, rand);
    copy(begin(v1), end(v1), ostream_iterator<unsigned int>(cout, " "));
    cout << endl;
    
    vector<unsigned int> v2;
    transform(begin(v1), end(v1), back_inserter(v2), bind(modulus<unsigned int>(),_1,10));
    copy(begin(v2), end(v2), ostream_iterator<unsigned int>(cout, " "));
    cout << endl;
    
    transform(begin(v2), end(v2), begin(v2), bind(plus<unsigned int>(),_1,1));
    copy(begin(v2), end(v2), ostream_iterator<unsigned int>(cout, " "));
    cout << endl;

    cout << accumulate(begin(v2), end(v2), 0);
    cout << endl;

    cout << accumulate(begin(v2), end(v2), 1, multiplies<unsigned int>()) << endl;
    string stuff[] = {"go","ahead","make","my","day"};
    cout << accumulate(begin(stuff),end(stuff),string("")) << endl;
}

/* Output:
16807 282475249 1622650073 984943658 1144108930 470211272 101027544 1457850878 1458777923 2007237709 
7 9 3 8 0 2 4 8 3 9 
8 10 4 9 1 3 5 9 4 10 
63
15552000
goaheadmakemyday
*/
