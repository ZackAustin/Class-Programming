// Shows classes that hold a pointer to each other
class A;

class B {
    A* ptrA;
    // ...
};

class A {
    B* ptrB;
    // ...
};
