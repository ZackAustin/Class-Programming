// Overloading [] operator with something other
// than an integer.
// Foreshadows maps

#include <iostream>
using namespace std;

// Name has a first name and a last name
// Later we will see map, which uses a general
// key-value pair
// 
class Name
{
friend class NameList;
	
	const string first;
	const string last;
	
public:
	Name (const string& f, const string& l) : first (f), last(l) {}
	
};

// Fixed size list of names
class NameList
{
	static const int SIZE = 10;
	
	Name*	list[SIZE];
	int 	howmany;
	
public:
	NameList() : howmany(0) {}
	
	~NameList() {
		for (int i = 0; i < howmany; i++)
			delete list[i];
	}
	
	void add (const string& f, const string& l) {
		if (howmany < SIZE)
			list[howmany++] = new Name (f, l);
	}
	
	// Overloaded [] operator: Search the list by first name,
	// returns the last name
	string operator[] (const string& f)
	{
		for (int i = 0; i < howmany; i++)
			if (list[i]->first == f)
				return list[i]->last;
		return f + " Not found";
	}
	
	// Search the list by index number, returns the FIRST name.
	// Not necessarily good programming practice to overload
	// an operator to return different things, but this shows that
	// it can be done
	string operator[] (int i)
	{
		if (i < 0 || i >= howmany)
			return "Illegal index";
		return list[i]->first;
	}
};

int main()
{
	NameList nl;
	nl.add ("John", "Johnson");
	nl.add ("Henry", "Purcell");
	nl.add ("Christoph", "Baumeister");
	nl.add ("Ivan", "Petrovich");
	
	cout << nl[2] << endl;		// First name at position 2
	cout << nl["Henry"] << endl;	// Last name of Henry
	cout << nl["Peter"] << endl;	// Nobody named Peter
	cout << nl[nl[0]] << endl;	// Last name at position 2

}

	
