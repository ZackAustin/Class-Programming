// compose3.cpp: Reverses the sequence to enable range-based for loop. Illustrates bind.
#include <algorithm>
#include <functional>
#include <iostream>
#include <vector>
using namespace std;
using namespace std::placeholders;

using Fun = function<double(double)>;

class Composer {
private:
    vector<Fun>& funs;
public:
    Composer(vector<Fun>& fs) : funs(fs) {
        reverse(funs.begin(),funs.end());
    }
    double operator()(double x) const {
        double result = x;
        for (auto p: funs)
            result = p(result); // p is not a function ptr now
        return result;
    }
};

// A function object type
struct g {
    double operator()(double x) {
        return x*x;
    }
};

int main() {
    auto f = bind(divides<double>(),_1,2.0);
    vector<Fun> funs{f,g(),[](double x){return x+1;}};
    Composer comp(funs);
    cout << comp(2.0) << endl;  // 4.5
}
