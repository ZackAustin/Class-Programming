#include <iostream>
using namespace std;

void printbits(unsigned long long n) {
	unsigned long long mask = 1uLL << 63;
	while (mask) {
		cout << !!(n & mask);
		mask >>= 1;
	}
	cout << endl;
}

int main() {
	unsigned int x = 0xf0f0f0f0;
	printbits(x);
	printbits(1u);
	
	union overlay {
		unsigned char bytes[4];
		unsigned int n;
	};
	overlay y;
	y.n = 1u;
	cout << hex;
	for (int i = 0; i < 4; ++i) {
		unsigned int b = static_cast<unsigned int>(y.bytes[i]);
		cout << b << ' ';
	}
	cout << endl;
}

/* Output:
0000000000000000000000000000000011110000111100001111000011110000
0000000000000000000000000000000000000000000000000000000000000001
1 0 0 0
*/