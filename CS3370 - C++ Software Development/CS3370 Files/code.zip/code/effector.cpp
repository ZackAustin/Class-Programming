#include <cassert>
#include <iostream>
#include <limits>  // For max()
#include <sstream>
#include <string>
using namespace std;

// Put out a prefix of a string:
class Fixw {
  string str;
public:
  Fixw(const string& s, int width) : str(s) {
      str.resize(width,' ');
  }
  friend ostream& operator<<(ostream& os, const Fixw& fw) {
    return os << fw.str;
  }
};

// Print a number in binary:
typedef unsigned int uint;

class Bin {
  uint n;
public:
  Bin(uint nn) { n = nn; }
  friend ostream& operator<<(ostream& os, const Bin& b) {
    const uint UMAX = numeric_limits<uint>::max();
    uint bit = ~(UMAX >> 1); // Top bit set
    while(bit) {
      os << (b.n & bit ? '1' : '0');
      bit >>= 1;
    }
    return os;
  }
};

int main() {
  string words = "Things that make us happy, make us wise";
  for(int i = words.size(); --i >= 0;) {
    ostringstream s;
    s << Fixw(words, i);
    string res1 = s.str();
    cout << res1 << endl;
    assert(res1 == words.substr(0, i));
  }
  cout << '"' << Fixw(words,50) << "\"\n";
  
  ostringstream xs, ys;
  xs << Bin(0xCAFEBABEUL);
  string res2 = xs.str();
  cout << res2 << endl;
  assert(res2 == "11001010111111101011101010111110");
  ys << Bin(0x76543210UL);
  string res3 = ys.str();
  cout << res3 << endl;
  assert(res3 == "01110110010101000011001000010000");
} ///:~

/* Output:
Things that make us happy, make us wis
Things that make us happy, make us wi
Things that make us happy, make us w
Things that make us happy, make us 
Things that make us happy, make us
Things that make us happy, make u
Things that make us happy, make 
Things that make us happy, make
Things that make us happy, mak
Things that make us happy, ma
Things that make us happy, m
Things that make us happy, 
Things that make us happy,
Things that make us happy
Things that make us happ
Things that make us hap
Things that make us ha
Things that make us h
Things that make us 
Things that make us
Things that make u
Things that make 
Things that make
Things that mak
Things that ma
Things that m
Things that 
Things that
Things tha
Things th
Things t
Things 
Things
Thing
Thin
Thi
Th
T

11001010111111101011101010111110
01110110010101000011001000010000
*/
