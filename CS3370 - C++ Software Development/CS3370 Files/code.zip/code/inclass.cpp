#include <iostream>
using namespace std;

struct Foo {
    int x = 0;
    const static int y = 1;
};

int main() {
    Foo f;
    cout << f.x << ", " << Foo::y << endl;
}