#include <iostream>
using namespace std;

int main()
{
   cout << "Enter an int: " << flush;
   for (int i = 0; i < 1000000000; ++i)
      ;
}

