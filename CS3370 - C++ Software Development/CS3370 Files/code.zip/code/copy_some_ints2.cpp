// copy_some_ints2.cpp
#include <algorithm>
#include <array>
#include <cstddef>
#include <functional>
#include <iostream>
#include <iterator>
using namespace std;
using namespace std::placeholders;

int main() {
  enum {N = 3};
  array<int,N> a{ 10, 20, 30 };
  decltype(a) b;
  auto endb = copy_if(begin(a), end(a), begin(b), bind(less<int>(),_1,15));
  copy(begin(b),endb,ostream_iterator<int>(cout,"\n"));	// 10
}