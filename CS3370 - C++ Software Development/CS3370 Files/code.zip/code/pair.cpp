// pair.cpp
#include <iostream>
#include <typeinfo>
#include <utility>
using namespace std;

template<class T, class U>
void print_pair(const pair<T,U>& p) {
    cout << "first: " << p.first << ", second: " << p.second << endl;
}

int main() {
    pair<int,string> p1(10,"ten");
    print_pair(p1);
    auto p2 = make_pair(20,string("twenty"));
    print_pair(p2);
}

/*
first: 10, second: ten
first: 20, second: twenty
*/