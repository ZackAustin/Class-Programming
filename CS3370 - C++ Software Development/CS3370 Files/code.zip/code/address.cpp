#include <iostream>
using namespace std;

int main()
{
   int i = 7, j = 8;
   cout << "i == " << i << ", &i == " << &i << endl;
   cout << "j == " << j << ", &j == " << &j << endl;
}
