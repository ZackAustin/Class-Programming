// Uses vector to read an arbitrary number of ints
#include <cassert>
#include <cstddef>   // For size_t
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

// Read ints from a file into an array
void readInts(const string& fileName, vector<int>& nums) {
   // Read numbers
   ifstream inf(fileName);
   if (inf) {
      int num;
      while (inf >> num)
         nums.push_back(num);
   }
}

int main(int argc, char* argv[]) {
   if (argc > 1) {
      vector<int> nums;
      readInts(argv[1], nums);
      cout << "Read " << nums.size() << " numbers\n";
      for (auto i: nums)
         cout << i << ' ';
      cout << endl;
   }
}

/* Outut from the command: $holdInts2 nums.dat:
Read 21 numbers
5737 8716 5982 1804 6148 7004 5861 8292 3958 8948 3307 7194 1748 4800 1660 4131 8275 7370 9081 6934 3220 
*/