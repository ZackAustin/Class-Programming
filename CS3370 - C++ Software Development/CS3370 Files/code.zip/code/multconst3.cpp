int main() {
    char* pc;
    const char* cpc = pc;
    char** ppc;
    const char* const* cppc = ppc;
}
