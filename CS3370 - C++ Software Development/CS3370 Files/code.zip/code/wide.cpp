#include <iostream>
#include <string>
using namespace std;

int main() {
    wchar_t wc = L'\u00F6';
    wcout << wc << " (" << sizeof (wc) << ")\n";
    char c = '\xF6';
    cout << c << " (" << sizeof (c) << ")\n";

    cout << "Narrow:\n";
    for (unsigned int i = 128; i < 255; ++i)
        cout << char(i) << endl;

    cout << "Wide:\n";
    for (unsigned int i = 2048; i < 65535; ++i)
        wcout << i << ": " << static_cast<wchar_t>(i) << endl;
}