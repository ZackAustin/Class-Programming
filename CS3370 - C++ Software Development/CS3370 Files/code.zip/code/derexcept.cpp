#include <iostream>
using namespace std;

struct BaseExcept {BaseExcept() {cout << "BaseExcept\n";}};

struct DerivedExcept : BaseExcept {DerivedExcept() {cout << "DerivedExcept\n";}};

struct RogueExcept {RogueExcept() {cout << "RogueExcept\n";}};

class Base
{
public:
   virtual void f() {throw BaseExcept();}
};

class Derived : public Base
{
public:
//   void f() {throw BaseExcept();}
//   void f() {throw DerivedExcept();}
//   void f() throw() {}    // Note exception specification
   void f() {}
};

int main()
{
   Derived d;
   try
   {
      d.f();
   }
   catch(BaseExcept&)
   {}
}

