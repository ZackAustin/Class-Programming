#include <iostream>
#include <cstddef>
using namespace std;

template<typename T = int>
class MyType
{
public:
   size_t size() const
   {
      return sizeof(T);
   }
};

int main()
{
   MyType<double> m1;
   cout << m1.size() << endl;
   MyType<> m2;
   cout << m2.size() << endl;
}

/* Output:
8
4
*/


