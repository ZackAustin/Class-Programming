#include <iostream>
#include <thread>
using namespace std;

void f(const string & s) {
    for (int i=0; i < 10; ++i)
        cout << s << endl;
}

int main() {
    thread t1{f,"Dessert Topping"};
    thread t2{f,"Floor Wax"};
    t1.join();
    t2.join();
}

/* Output:
DFelsosoerr tW aTxopping

DFelsosoerr tW aTxo
ppFilnogo
r DWeasxs
erFtl oToorp pWianxg

FDleososre rWta xT
opFplionogr
 WDaexs
seFrlto oTro pWpaixn
g
FlDoeosrs eWratx 
ToFplpoionrg 
WaDxe
ssFelroto rT oWpapxi
ng
Dessert Topping
Dessert Topping
Dessert Topping
*/
