#include <iostream>
using namespace std;

int main() {
	cout << __func__ << endl;
}