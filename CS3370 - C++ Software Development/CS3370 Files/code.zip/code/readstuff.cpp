#include <iostream>
#include <string>
#include <sstream>
#include <cassert>
using namespace std;

int main()
{
   int theInt = 0;
   do
   {
      string line;
      cout << "Enter an int between 1 and 5: ";
      getline(cin, line);
      istringstream is(line);
      if (!(is >> theInt))
         is.clear();
      assert(is);
   } while (theInt < 1 || theInt > 5);
   cout << "You entered " << theInt << endl;
}
