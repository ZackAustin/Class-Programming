class MyClass {
  static const int i = 1;
  static const double x = 1.0;
};

