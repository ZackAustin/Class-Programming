using FType = void (*)(char,double);

void g(char,double){}

int main() {
    FType f = g;
}