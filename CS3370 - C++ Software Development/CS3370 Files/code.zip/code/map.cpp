#include <iostream>
#include <map>
#include <string>
using namespace std;

int main()
{
    // Insert some elements (three ways):
    map<string, string, greater<string>> m;
    m.insert(make_pair("Alabama","Montgomery"));
    m.insert({"Tennessee","Knoxville"});
    m["Georgia"] = "Atlanta";
    m["Tennessee"] = "Nashville";
//    m.emplace("Michigan","Lansing");  // Not implemented yet

    // Print the map:
    for (const auto& elem: m)
        cout << '{' << elem.first << ',' << elem.second << "}\n";
    cout << endl;

    // Retrieve via a key:
    cout << '"' << m["Georgia"] << '"' << endl;
    cout << m.size() << endl;
    cout << '"' << m["Texas"] << '"' << endl;
    cout << m.size() << endl;
}