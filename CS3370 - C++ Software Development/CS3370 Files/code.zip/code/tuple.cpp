// tuple.cpp
#include <cassert>
#include <iostream>
#include <string>
#include <tuple>
#include <utility>      // For make_tuple
using namespace std;

// A tuple type
using MyTuple = tuple<int,string>;

// Increment tuple elements
MyTuple incr(const MyTuple& t) {
    return MyTuple(get<0>(t)+1, get<1>(t) + "+one");
}

int main() {
    MyTuple tup0(1,"text");
    auto tup1 = incr(tup0);
    cout << get<0>(tup1) << ' ' << get<1>(tup1) << endl;
    
    auto tup2 = make_tuple(2,string("text+one"));
    assert(tup1 == tup2);
    
    int n;
    string s;
    tie(n,s) = incr(tup2);
    cout << n << ' ' << s << endl;
}

/* Output:
2 text+one
3 text+one+one
*/