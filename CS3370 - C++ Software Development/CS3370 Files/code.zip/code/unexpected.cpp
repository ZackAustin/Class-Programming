#include <iostream>
#include <cstdlib>
using namespace std;

// Illustrates an unexpected handler
void myHandler()
{
   cout << "unexpected() called\n";
   exit(1);
}

void g()
{
   throw 1;
}

void f() throw()
{
   g();
}

int main()
{
   set_unexpected(myHandler);
   f();
}

