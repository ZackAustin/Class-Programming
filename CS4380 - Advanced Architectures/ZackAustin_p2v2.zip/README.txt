Language C++:

Compiled using MSVC:
cd <directory-of-vm.cpp>
cl /EHsc vm.cpp
Execute: vm.exe proj1.asm