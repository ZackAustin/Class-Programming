Zack Austin 11/11/13

mvsc compiled.

ex: vm.exe proj3.asm

Bug: One bug I did not solve. If you enter one non-numeric character, like g, it alternates between displaying "g is not a number" and "Operand is 0".

If quitting and it happens just type @ a second time to quit if it happens to you. Sorry about that.