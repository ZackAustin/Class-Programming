Zack Austin 11/29/13

mvsc compiled.

ex: vm.exe proj4.asm

Instructions: Enter just 1 integer per line.

Locks, unlocks and other Multithread commands found between lines 618 and 690 of assembly file.