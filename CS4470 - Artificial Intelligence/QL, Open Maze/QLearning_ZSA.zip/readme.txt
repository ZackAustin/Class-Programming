Zack Austin
12/12
QLearning Stochastic Maze

Win 7 exe, compiled with cl mvsc, "maze.exe". It outputs to the file "output.txt" with a solution path and Q values for cells. A cell named 45 refers to the cell in row 4 column 5. I don't have a nice visual representation of it. All my code is in 'main.cpp'. I had to rush this project and could not debug or refactor my code, but I think it's correct for the most part.

The values are read clockwise for qValues. Top, right, down, left.