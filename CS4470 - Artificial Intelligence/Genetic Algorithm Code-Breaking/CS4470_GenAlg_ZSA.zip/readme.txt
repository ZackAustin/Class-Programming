Zack Austin
CS4470

Written in C++, exe for Win7.

Sorry for being late a couple hours, I was writing the paper with open office and the charts were being a pain with margins.