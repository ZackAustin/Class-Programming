#include "ObserverPattern.h"
using namespace std;
#include <fstream>
#include <vector>
#include <sstream>
#include <iostream>
#include <list>

void parseStockInput(vector<LocalStock> &stockObject, list<string> &input, int &counter);
void stockSnapshot(vector<LocalStock> &stockObject, list<string> &fileInput, ifstream& stockDataFile, int &initialDate, int &snapCounter);

int main()
{
	KeepRunning kr;
	//Our stock object in a vector, for each snapshot.
	vector<LocalStock> stockObject;
	LocalStock dummyStock;
	stockObject.push_back(dummyStock);
	AverageReport AverageObserver;
	Change10Report change10Observer;
	SelectionReport selectionObserver;
	std::list<string> fileInput;

	ifstream stockDataFile;
	stockDataFile.open("Ticker.dat", ios::binary);
	if (!stockDataFile.is_open() || !stockDataFile)  // Did the open work?
	{
		cerr << "Can't open file for input!\n";
		return 1;
	}
	//Data field at a time.
	int initialDate = 0;
	string tempField;
	int snapshotNumber = 0;
	bool finishedLine = false;
	bool initialInput = true;
	//while not end of file.
	while (!stockDataFile.eof())
	{
		LocalStock aStock;
		stockObject.push_back(aStock);
		AverageReport anAvgReport;
		Change10Report aPercent10Report;
		SelectionReport aSelection;
		stockObject[snapshotNumber].registerObserver(anAvgReport);
		if (snapshotNumber >= 2 && snapshotNumber <= 4)
			stockObject[snapshotNumber].registerObserver(aPercent10Report);
		if (snapshotNumber == 2 || snapshotNumber == 3)
			stockObject[snapshotNumber].registerObserver(aSelection);

		//Take a snapshot.
		stockSnapshot(stockObject, fileInput, stockDataFile, initialDate, snapshotNumber);
		snapshotNumber++;
	}
	stockDataFile.close();
	for (int i = stockObject.size() - 1; i > 0; i--)
	{
		stockObject[i].removeObserver(AverageObserver);
		stockObject[i].removeObserver(change10Observer);
		stockObject[i].removeObserver(selectionObserver);
	}
	stockObject.clear();
	return 0;
}

//Parse out a line of stock data input into LocalStock Object.
void parseStockInput(vector<LocalStock> &stockObject,list<string> &fileInput, int &counter)
{
	if (fileInput.size() > 0)
	{
		char* endptr;
		//PERatio from list input.
		stockObject[counter].setPERatio(strtod(fileInput.front().c_str(), &endptr));
		fileInput.pop_front();
		//52WeekLow from list input.
		stockObject[counter].set_52WeekLow(strtod(fileInput.front().c_str(), &endptr));
		fileInput.pop_front();
		//52WeekHigh from list input.
		stockObject[counter].set_52WeekHigh(strtod(fileInput.front().c_str(), &endptr));
		fileInput.pop_front();
		//YTDPercentChange from list input.
		stockObject[counter].set_YTDPercentChange(strtod(fileInput.front().c_str(), &endptr));
		fileInput.pop_front();
		//percentChange from list input.
		stockObject[counter].set_percentChange(strtod(fileInput.front().c_str(), &endptr));
		fileInput.pop_front();
		//dollarChange from list input.
		stockObject[counter].set_dollarChange(strtod(fileInput.front().c_str(), &endptr));
		fileInput.pop_front();
		//currentPrice from list input.
		stockObject[counter].set_currentPrice(strtod(fileInput.front().c_str(), &endptr));
		fileInput.pop_front();
		//ticketSymbol from list input.
		stockObject[counter].set_tickerSymbol(fileInput.front());
		fileInput.pop_front();
		//company Name from list input.
		string tempCompanyName;
		while (fileInput.size() > 0)
		{
			tempCompanyName = fileInput.front() + " " + tempCompanyName;
			fileInput.pop_front();
		}
		stockObject[counter].set_companyName(tempCompanyName);
	}
}

//Run one snapshot of Ticker.Data file.
void stockSnapshot(vector<LocalStock> &stockObject, list<string> &fileInput, ifstream& stockDataFile, int &initialDate, int &snapCounter)
{

	//Data field at a time.
	string tempField;
	bool finishedLine = false;

	//while on this snapshot.
	while (tempField != "Done")
	{
		//Parse a data field.
		stockDataFile >> tempField;
		char c = tempField[0];

		//Checking if we're on a new line of input.
		if (c == '-' || (c >= '0' && c <= '9'))
			finishedLine = true;

		if (((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) && finishedLine)
		{
			parseStockInput(stockObject, fileInput, snapCounter);
			finishedLine = false;
		}

		fileInput.push_front(tempField);
		//If Date Field.
		if (tempField == "Last")
		{
			if (initialDate > 0)
			{
				//Record last snapshot.
				stockObject[snapCounter].stockChanged();
			}
			fileInput.pop_front();
			string tempDate;
			getline(stockDataFile, tempDate, '\r');
			tempDate = tempField + tempDate;
			stockObject[snapCounter + 1].set_date(tempDate);
			initialDate++;
			tempField = "Done";
		}

		if (stockDataFile.eof())
		{
			tempField = "Done";
			//Record last snapshot.
			stockObject[snapCounter].stockChanged();
		}
	}
	//end of a snapshot.
}