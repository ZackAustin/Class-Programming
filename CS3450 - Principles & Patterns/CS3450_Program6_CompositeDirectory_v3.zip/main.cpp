//Main.cpp
// Name:		Zack Austin
// Date:		11/13/13
// Class:		CS 3450
// Assignment:	Program 6 Directory Traversal
// Purpose:		Learn how to simulate a command shell using Composite Pattern and internal iteration.

using namespace std;

#include "Explorer.h"

int main()
{
	string fileInput;
	while (fileInput != "q")
	{
		cout << "Enter File for Directories or q to quit:\n";

		getline(cin, fileInput);
		ifstream in;
		in.open(fileInput);
		if (in.good())
		{
			Explorer exp;
			exp.setupDirectory(in);
			exp.process(cin, cout);
		}
		else if (fileInput == "q") { cout << "Program Finished.\n"; }
		else
			cout << "Invalid File Name\n";
		in.close();
	}
	return 0;
}
