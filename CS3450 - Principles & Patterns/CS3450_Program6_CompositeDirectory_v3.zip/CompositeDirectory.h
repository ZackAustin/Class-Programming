//CompositeDirectory.h

#ifndef COMPOSITEDIRECTORY_H
#define COMPOSITEDIRECTORY_H
#pragma once

#include <vector>
#include <algorithm>
#include <functional>
#include <iostream>

using namespace std;

//composite interface
class Component
{
public:
	virtual ~Component() {}
//Transparency over Safety:
	virtual void Add(Component *aC) = 0;
	virtual void Remove(Component *aC) = 0;
	virtual vector<Component*> getDirNodes() = 0;
	virtual Component* getParent() = 0;
	//lists the entries in the current directory horizontally
	virtual string list() = 0;
	//prints a hierarchical listing of the current directory subtree(starting from the current node)
	virtual string listall() = 0;
	//prints the number of files (not directories) in the current directory
	virtual int count() = 0;
	//prints the number of files(not directories) in the subtree starting from the current node
	virtual int countall() = 0;
	//moves up the tree to the parent (like cd ..)
	virtual Component* up() = 0;
	//changes directory to the named, adjacent subdirectory
	virtual Component* chdir(string dirName) = 0;
	//getters
	virtual string getName() = 0;
	virtual int getCount() = 0;
	virtual void setParent(Component* par) = 0;
};

//class File, It's a leaf.
class File : public Component
{
	string name;
	int fileCount;
	int spacing;
	Component* parentLink;
public:
	File(string n, int spc) : name(n), spacing(spc){fileCount = 1; parentLink = 0;}
	~File(){}

	void Add(Component *aC){}//do nothing on leaves
	void Remove(Component *aC){}//do nothing on leaves

	vector<Component*> getDirNodes() { vector<Component*> temp;  return temp; } //couple getters
	string getName(){ return name; }
	int getCount(){ return fileCount; }
	void setParent(Component* par) { this->parentLink = par; }
	Component* getParent() { return this->parentLink; }

	string list(){return this->getName() + " ";}//diff file cmds
	string listall()
	{
		string temp;
		int space = this->spacing;
		for (int i = space; i > 0; i--)
			temp += " ";
		return temp + this->getName() + "\n";
	}
	int count(){return this->getCount();}
	int countall(){return this->getCount();}
	Component* up() { return nullptr; }//leaf, files cant change directories.
	Component* chdir(string dirName){ return nullptr; }//leaf, cant change directories
};

//class Directory, It's a Composite item.
class Directory : public Component
{
	string name;
	int fileCount;
	int spacing;
	vector<Component*> directoryNodes;
	Component* parentLink;
public:
	Directory(string n, int spc) : name(n), spacing(spc){fileCount = 0; parentLink = 0;}
	~Directory()
	{
		for (int i = 0; i < directoryNodes.size(); i++)
			delete directoryNodes[i];
	}

	void Add(Component *aC)
	{
		aC->setParent(this);
		directoryNodes.push_back(aC);
	}
	void Remove(Component *aC)
	{
		auto position = find(directoryNodes.begin(), directoryNodes.end(), aC);
		if (position != directoryNodes.end())
			directoryNodes.erase(position);
	}

	void setParent(Component* par){this->parentLink = par;}
	Component* getParent(){ return this->parentLink; }
	string getName(){ return name; }
	int getCount(){ return fileCount; }
	vector<Component*> getDirNodes() { return directoryNodes; }

	string list()
	{
		string compilate;
		for (auto iter = directoryNodes.begin(); iter != directoryNodes.end(); iter++)
			compilate += " " + (*iter)->getName() + " ";
		return compilate;
	}

	string listall()
	{
		string compilate, temp;
		int space = this->spacing;
		for (int i = space; i > 0; i--)
			temp += " ";
		compilate += temp + this->name + "\n";
		for (auto iter = directoryNodes.begin(); iter != directoryNodes.end(); iter++)
			compilate += (*iter)->listall();
		return compilate;
	}

	int count()
	{
		int counter = 0;
		for (auto iter = directoryNodes.begin(); iter != directoryNodes.end(); iter++)
			counter += (*iter)->getCount();
		return counter;
	}

	int countall()
	{
		int counter = 0;
		for (auto iter = directoryNodes.begin(); iter != directoryNodes.end(); iter++)
			counter += (*iter)->countall();
		return counter;
	}

	Component* up()
	{
		if (parentLink != nullptr)
			return parentLink;
		else
		{
			cout << "No Such Parent Directory.\n";
			return this;
		}
	}

	Component* chdir(string dirName)
	{
		if (dirName.back() != ':')
			dirName += ":";
		Component* temp = nullptr;
		for (auto iter = directoryNodes.begin(); iter != directoryNodes.end(); iter++)
			if ((*iter)->getName() == dirName)
				temp = (*iter);
		if (temp != nullptr)
			return temp;
		else
		{
			if (this->parentLink != nullptr)
			{
				if (this->parentLink->getName() == dirName)
					return this->parentLink;
			}
			else
			{
				cout << "No Such Adjacent Directory.\n";
				return this;
			}
		}
	}

	Component* GetChild(int c){return directoryNodes[c];}
};

#endif;
