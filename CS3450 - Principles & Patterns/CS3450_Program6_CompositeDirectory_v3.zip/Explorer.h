//Explorer.h

#ifndef EXPLORER_H
#define EXPLORER_H
#include <fstream>
#include <string>
#include <sstream>
#include <iterator>
#include <vector>
#include <iostream>

#pragma once

#include "CompositeDirectory.h"

const int DIRECTORY_LEVEL = 3;
const int SUB_DIRECTORY = 6;

class Explorer
{
	Component* currentDirectory;
	string input;
public:
	Explorer(){currentDirectory = 0;}
	~Explorer()
	{
		if (currentDirectory != nullptr)
		{
			while (currentDirectory->getParent() != nullptr)
				currentDirectory = currentDirectory->getParent();
			delete currentDirectory;
		}
	}

	void setupDirectory(ifstream& in)
	{
		while (!in.eof())
		{
			getline(in, input);
			//spaces
			std::string::size_type firstNonSpace = input.find_first_not_of(' ');
			//seperate input by spacing & remove space.
			istringstream iss(input);

            std::istream_iterator<std::string> beg(iss), end;

            std::vector<std::string> tokens(beg, end); // done!

			//set currentDir to root first.
			if (currentDirectory != nullptr)
			{
				while (currentDirectory->getParent() != nullptr)
					currentDirectory = currentDirectory->getParent();
			}

			//if we read input:
			if (tokens.size() > 0)
			{
				//root
				if (firstNonSpace == 0)
					currentDirectory = new Directory(tokens[0], firstNonSpace);
				//adding to root
				else if (firstNonSpace == DIRECTORY_LEVEL)
				{
					if (tokens[0].back() == ':')
						currentDirectory->Add(new Directory(tokens[0], firstNonSpace));
					else
						currentDirectory->Add(new File(tokens[0], firstNonSpace));
				}
				//go to directory, add to it.
				else if (firstNonSpace >= SUB_DIRECTORY && firstNonSpace % DIRECTORY_LEVEL == 0)
				{
					//set currentDir correctly. It's spacing - 3, the most recent dir added for level.
					int temp = firstNonSpace - DIRECTORY_LEVEL;
					while (temp > 0)
					{
						auto dirNodes = currentDirectory->getDirNodes();
						for (int i = dirNodes.size() - 1; i >= 0; i--)
						{
							if (dirNodes[i]->getName().back() == ':')
							{
								currentDirectory = dirNodes[i];
								i = -1;
							}
						}
						temp -= DIRECTORY_LEVEL;
					}

					//currentDir set correctly, add to it.
					if (tokens[0].back() == ':')
						currentDirectory->Add(new Directory(tokens[0], firstNonSpace));
					else
						currentDirectory->Add(new File(tokens[0], firstNonSpace));
				}
				else
				{
					//file spacing for line is incorrect.
				}
			}
		}
	}

	void process(istream& in, ostream& out)
	{
		if (currentDirectory != nullptr)
		{
			while (input != "q")
			{
				out << currentDirectory->getName() << ">";
				getline(in, input);
					istringstream iss(input);
					vector<string> tokens{ istream_iterator<string>{iss}, istream_iterator<string>{} };
					if (tokens[0] == "list")
						out << currentDirectory->list() << endl;
					else if (tokens[0] == "listall")
						out << currentDirectory->listall() << endl;
					else if (tokens[0] == "chdir")
					{
						if (tokens.size() > 1)
							currentDirectory = currentDirectory->chdir(tokens[1]);
						else { cout << "No Directory Given for Command.\n"; }
					}
					else if (tokens[0] == "up")
						currentDirectory = currentDirectory->up();
					else if (tokens[0] == "count")
						out << currentDirectory->count() << endl;
					else if (tokens[0] == "countall")
						out << currentDirectory->countall() << endl;
					else if (tokens[0] == "q")
						out << "Finished with File Directory. Process Another?\n";
					else { out << "Not a Valid Command.\n"; }
			}
		}
	}
};

#endif
