//Queue.h

#ifndef QUEUE_H
#define QUEUE_H
#pragma once
#include <queue>
#include <typeinfo>
#include "queueStorage.h"
#include <string>

using namespace std;

//Our Generic Queue Interface Implementation
template<class T> class Queue
{
public:
	//pointer to the initial implementation class.
	Queue(queueStorage<T>* reference) : storageReference(reference){}
	virtual ~Queue(){}

	//Our Queue Implementation just calls our useAdd and other methods in our storage classes from the pointer.
	const void add(T val)
	{
		storageReference->useAdd(val);
	}
	//Call to the proper Get() in storage and returns whatever generic type that may be.
	T get()
	{
		return storageReference->useGet();
	}

	//More storage call functions, this one for removing an element of FIFO Order.
	void remove()
	{
		storageReference->useRemove();
	}

	//Call Size of Queue.
	int size()
	{
		return storageReference->useSize();
	}

	//Calls clear for Queue.
	void clear()
	{
		storageReference->useClear();
	}

	//Function to allow us to change storage structures during runtime.
	void changeImpl(queueStorage<T>* ref)
	{
		//first empties the new implementation.
		ref->useClear();
		//While there's stuff in our Current Implementation.
		while (!storageReference->checkEmpty())
		{
			//Add That Stuff to Our New Implementation.
			ref->useAdd(storageReference->useGet());
			//Remove it from the Current Implementation, we don't need it!
			storageReference->useRemove();
		}
		//Set to New Implementation.
		storageReference = ref;
	}

private:
	//Pointer to our underlying storage data structures.
	queueStorage<T>* storageReference;
};

#endif