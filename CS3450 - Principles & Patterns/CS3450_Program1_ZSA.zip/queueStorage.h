//queueStorage.h

#ifndef QUEUESTORAGE_H
#define QUEUESTORAGE_H
#pragma once

using namespace std;
#include <list>
#include <deque>
#include <queue>
#include "Queue.h"

//Base abstract class queueStorage, for various sequential containers to implement our queue container adaptor.
template<class T> class queueStorage
{
public:
	virtual ~queueStorage() {}
	//Various virtual functions to be implemented on our storage structure.
	virtual void useAdd(T val) = 0;
	virtual T useGet() = 0;
	virtual void useRemove() = 0;
	virtual int useSize() = 0;
	virtual void useClear() = 0;
	virtual bool checkEmpty() = 0;
private:
};

//Our first sequential container to implement our generic Queue, using std::deque.
template<class T>
class Deque : public queueStorage<T>
{
public:
	Deque(){}
	~Deque(){}
	//std::deque object.
	deque<T> storage;
	//ADD - Create New Element, FIFO Order.
	void useAdd(T val)
	{
		storage.push_back(val);
	}

	//GET - Return First Element FIFO Order.
	T useGet()
	{
		return storage.front();
	}

	//REMOVE - Delete First Element FIFO Order.
	void useRemove()
	{
		storage.pop_front();
	}

	//SIZE - Number of Elements in Deque.
	int useSize()
	{
		return storage.size();
	}

	//CLEAR - Empty Deque Data Structure.
	void useClear()
	{
		storage.clear();
	}

	//EMPTY - Boolean check whether the Deque is Empty or not.
	bool checkEmpty()
	{
		return storage.empty(); //Returns true if empty.
	}
};

//Our other implemented sequential container, using std::list.
template <class T>
class List : public queueStorage<T>
{
public:
	List(){}
	~List(){}
	//std::list object.
	list<T> storage;

	//Calls to std::list functions for implementation.
	void useAdd(T val)
	{
		storage.push_back(val);
	}

	T useGet()
	{
		return storage.front();
	}

	void useRemove()
	{
		storage.pop_front();
	}

	int useSize()
	{
		return storage.size();
	}

	void useClear()
	{
		storage.clear();
	}

	bool checkEmpty()
	{
		return storage.empty(); //returns true if list is empty.
	}

	//Implemented push_back for example, just calls our storage object std::list's push_back function.
	void push_back(T val)
	{
		storage.push_back(val);
	}
};

#endif

