//driver.cpp
// Name:		Zack Austin
// Date:		9/14/13
// Class:		CS 3450
// Assignment:	Program 1 Varying Implementation
// Purpose:		Learn how to vary a data structures type at runtime.

#include <string>
#include <iostream>
#include "Queue.h"
#include "queueStorage.h"
#include <stdio.h>     
#include <stdlib.h>     

template<class T>
void displayAndEmptyQueue(Queue<T> queue);

int main()
{
	cout << "Name:		Zack Austin\n";
	cout << "Date:		9/14/13\n";
	cout << "Class:		CS 3450\n";
	cout << "Assignment:	Program 1 - Varying Implementation\n";
	cout << "Purpose:	Learn how to vary a data structures type at runtime.\n\n";


	// Test ints
	Deque<int> deq;
	Queue<int> q(&deq);
	q.add(1);
	q.add(2);

	// Swap implementation
	List<int> lst;
	lst.push_back(3);
	q.changeImpl(&lst);
	q.add(4);
	q.add(5);
	displayAndEmptyQueue(q);

	// Test strings
	Deque<string> deq2;
	Queue<string> q2(&deq2);
	q2.add("1");
	q2.add("2");

	// Swap implementation
	List<string> lst2;
	lst2.push_back("3");
	q2.changeImpl(&lst2);
	q2.add("4");
	q2.add("5");
	displayAndEmptyQueue(q2);

	system("Pause");
}

//Function to display and empty our queue, implementing functions we wrote.
template<class T>
void displayAndEmptyQueue(Queue<T> queue)
{
	cout << "\n";
	while (queue.size() > 0)
	{
		cout << queue.get() << " ";
		queue.remove();
	}
}
