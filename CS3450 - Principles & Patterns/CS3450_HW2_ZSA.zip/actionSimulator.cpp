// Name:		Zack Austin
// Date:		9/9/13
// Class:		CS 3450
// Assignment:	HW2 Design Puzzle
// Purpose:		Go through basic OO Principes and Design for review through an action adventure game.

//actionSimulator.cpp
#include "Character.h"
#include <iostream>
using namespace std;


const int MAX_CHARS = 4;

int main()
{
	//Initialize abstract character class, initialize with character inherited class objects along with their designated initial weapon behaviors.
	Character* gameCharacters[MAX_CHARS];
	gameCharacters[0] = new King;
	gameCharacters[1] = new Queen;
	gameCharacters[2] = new Troll;
	gameCharacters[3] = new Knight;
	for (int i = 0; i < MAX_CHARS; ++i)
	{
		gameCharacters[i]->performWeapon();
		gameCharacters[i]->fight();
	}

	//change weapon for fun since we did part 4): setWeapon().
	cout << "\nLet's change a character's weapon!\n";
	gameCharacters[0]->setWeapon(new AxeBehavior);
	gameCharacters[0]->performWeapon();

	system("PAUSE");
}
