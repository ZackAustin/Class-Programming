//Character.cpp
#include "Character.h"
#include <iostream>
using namespace std;

void King::fight()
{
	cout << "I'll stick ya with the pointy end!\n";
}

void Queen::fight()
{
	cout << "My quiver is full. Be warned.\n";
}

void Troll::fight()
{
	cout << "Axe will whittle them down one by one.\n";
}

void Knight::fight()
{
	cout << "I unsheath my blade.\n";
}