// Character.h
#ifndef CHARACTER_H
#define CHARACTER_H

#include "WeaponBehavior.h"

class Character
{
public:
	Character(WeaponBehavior* w)
		: weapon(w) {}
	~Character()
	{
		delete weapon;
	}
	virtual void fight() = 0;
	void performWeapon()
	{
		weapon->useWeapon();
	}
	void setWeapon(WeaponBehavior* w)
	{
		weapon = w;
	}
private:
	WeaponBehavior* weapon;
};

class King : public Character
{
public:
	King() 
		: Character(new KnifeBehavior) {}
	void fight();
};

class Queen : public Character
{
public:
	Queen()
		: Character(new BowAndArrowBehavior) {}
	void fight();
};

class Troll : public Character
{
public:
	Troll() 
		: Character(new AxeBehavior) {}
	void fight();
};

class Knight : public Character
{
public:
	Knight() 
		: Character(new SwordBehavior) {}
	void fight();
};

#endif
