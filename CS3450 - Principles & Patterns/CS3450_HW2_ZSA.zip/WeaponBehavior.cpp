//WeaponBehavior.cpp
#include "WeaponBehavior.h"
#include <iostream>
using namespace std;

void KnifeBehavior::useWeapon()
{
	cout << "Knife Used!\n";
}

void BowAndArrowBehavior::useWeapon()
{
	cout << "Bow Used!\n";
}

void AxeBehavior::useWeapon()
{
	cout << "Axe Used!\n";
}

void SwordBehavior::useWeapon()
{
	cout << "Sword Used!\n";
}