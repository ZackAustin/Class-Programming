//WeaponBehavior.h
#ifndef WEAPON_BEHAVIOR_H
#define WEAPON_BEHAVIOR_H
#pragma once
class WeaponBehavior
{
public:
	virtual ~WeaponBehavior() {}
	virtual void useWeapon() = 0;
};

class KnifeBehavior : public WeaponBehavior
{
public:
	void useWeapon();
};

class BowAndArrowBehavior : public WeaponBehavior
{
public:
	void useWeapon();
};

class AxeBehavior : public WeaponBehavior
{
public:
	void useWeapon();
};

class SwordBehavior : public WeaponBehavior
{
public:
	void useWeapon();
};

#endif
