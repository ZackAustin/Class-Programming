#ifndef DECORATOR
#define DECORATOR
using namespace std;

#include <string>
#include <iostream>
#include <sstream>
#include <iomanip>

template<typename T>
class Output
{
public:
	virtual ~Output(){}
	virtual void write(const T&) = 0;
	virtual void writeString(const std::string&) = 0;
};

template<typename T>
class StreamOutput : public Output<T>
{
	std::ostream& sink;
public:
	explicit StreamOutput(std::ostream& stream) : sink(stream) {}
	void write(const T& t)
	{
		cout << t;
		sink << t;
	}
	void writeString(const std::string& s)
	{
		sink << s;
	}
};

//1.	LineOutput: adds a newline with every write

template<typename T>
class LineOutput : public Output<T>
{
	Output* out;
public:
	LineOutput(Output* o) : out(o) {}
	void write(const T& t)
	{
		out->write(t + "\n");
	}

	void writeString(const std::string& s)
	{
		out->writeString(s + "\n");
	}
};

// 2.	NumberedOutput: this also adds newlines, but precedes each write with the current line number
//		(1-based) right-justified in a field of width 5, followed by a colon and a space

template<typename T>
class NumberedOutput : public Output<T>
{
	ostringstream oss;
	Output* out;
	int writeCounter;
	int writeStringCounter;
public:
	NumberedOutput(Output* o) : out(o) { writeCounter = 1; writeStringCounter = 1; }
	void write(const T& t)
	{
		oss << std::setw(5) << std::right << writeCounter << ": ";
		out->write(oss.str() + t + "\n");
		writeCounter++;
		oss.clear();
		oss.str("");
	}

	void writeString(const std::string& s)
	{
		oss << std::setw(5) << std::right << writeStringCounter << ": ";
		out->writeString(oss.str() + s + "\n");
		writeStringCounter++;
		oss.clear();
		oss.str("");
	}
};

//3.	TeeOutput: writes to two streams at a time; the one it wraps,
//		plus one it receives as a constructor argument
template<typename T>
class TeeOutput : public Output<T>
{
	std::ofstream& secondStream;
	Output* out;
public:
	TeeOutput(Output* o, std::ofstream& stream) : out(o), secondStream(stream){}
	~TeeOutput(){secondStream.close();}
	void write(const T& t)
	{
		out->write(t);
		secondStream << t;
	}

	void writeString(const std::string& s)
	{
		out->write(s);
		secondStream << s;
	}
};

//4.	FilterOutput: writes only those objects that satisfy a certain condition (unary predicate),
//		received as a constructor parameter.

template<typename T>
class FilterOutput : public Output<T>
{
	Output* out;
	int predicateType;
public:
	FilterOutput(Output* o, int predType) : out(o),predicateType(predType)  {}
	void write(const T& t)
	{
		bool predicate;
		if (predicateType == 1)
			predicate = containsDigit(t);
		if (predicateType == 2)
			predicate = containsHashSign(t);
		if (predicate)
			out->write(t);
	}

	void writeString(const std::string& s)
	{
		bool predicate;
		if (predicateType == 1)
			predicate = containsDigit(s);
		if (predicateType == 2)
			predicate = containsHashSign(s);
		if (predicate)
			out->writeString(s);
	}

	bool containsDigit(const T& t)
	{
			return (t.find_first_of("0123456789") != std::string::npos);
	}
	bool containsHashSign(const T& t)
	{
		return (t.find_first_of("#") != std::string::npos);
	}
};

class KeepRunning
{
public:
	~KeepRunning()
	{
		std::cout << "\nEnd of Program 3. Check those files!";
		std::cin.get();
	}
};

//classes

#endif // !DECORATOR
