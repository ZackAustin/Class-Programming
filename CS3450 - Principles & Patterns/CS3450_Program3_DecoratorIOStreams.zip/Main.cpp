//Main.cpp
// Name:		Zack Austin
// Date:		10/2/13
// Class:		CS 3450
// Assignment:	Program 3 - Stream Decoration
// Purpose:		Learn how to apply the Decorator Pattern on IO Streams.

#include "DecoratorPattern.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>

using namespace std;

int fileInputPrompt(ifstream &decInputFile);
int fileOutputPrompt(ofstream &outFile);
std::vector<int> decorationsMenu(vector<int> &refTeeVec, vector < vector < int >> &refFilterVector);
template<typename T>
Output<T>* processDecorations(vector<int> &vec, Output<T>* out);
template<typename T>
void outputDecoration(ifstream &decInputFile, Output<T>* out);

int main()
{
	//programmer information
	cout << "Name:		Zack Austin\n";
	cout << "Date:		10/7/13\n";
	cout << "Class:		CS 3450\n";
	cout << "Assignment:	Program 3 - Stream Decoration\n";
	cout << "Purpose:	Learn how to apply the Decorator Pattern on IO Streams.\n\n";

	//	1.	When the program runs, it should prompt for a file to read.
	ifstream decInputFile;
	int fileError = fileInputPrompt(decInputFile);
	if (fileError == 1)
		return 1;

	//	2.	It then presents a menu of the desired decorations to apply.
	//			a.The user can select multiple decorations; they will be applied in order.
	//			b.If the user selects TeeOutput, prompt for a file name to direct the Tee output to.
	//			c.If the user selects FilterOutput, give the user a choice of at least two predicates to choose from.
	vector<int> teeDec;
	vector<vector<int>> filterDec;
	vector<int> filtVec1,filtVec2;
	filterDec.push_back(filtVec1);
	filterDec.push_back(filtVec2);
	vector<int> decorations = decorationsMenu(teeDec, filterDec);
	

	//	3.	Then produce the decorated output. Process Files line by line.
	//clobber file
	ofstream outputFile("Output.dat");  // filename is created.
	if (!outputFile)                // did the open work?
	{
		cerr << "Can't open file for output!\n";
		return 1;
	}

	//produce decorator chain from input file, line by line.
	Output<string>* outputr = new StreamOutput<string>(outputFile);
	//process TeeOutputs first.
	ofstream teeOut1;
	ofstream teeOut2;
	ofstream teeOut3;
	int teeCounter = 0;
	while (teeDec.size() > 0)
	{
		if (teeDec.back() == 3)
		{
			if (teeCounter == 0)
			{
				fileOutputPrompt(teeOut1);
				outputr = new TeeOutput<string>(outputr, teeOut1);
			}
			if (teeCounter == 1)
			{
				fileOutputPrompt(teeOut2);
				outputr = new TeeOutput<string>(outputr, teeOut2);
			}
			if (teeCounter == 2)
			{
				fileOutputPrompt(teeOut3);
				outputr = new TeeOutput<string>(outputr, teeOut3);
			}
			if (teeCounter > 2)
			{
				cerr << "Cant write to more than 3 streams.";
				return 1;
			}
			teeCounter++;
			teeDec.pop_back();
		}
	}

	//process middle of decorator chain (numberedline, line)
	outputr = processDecorations(decorations, outputr);

	//process filter (outermost wrappers) here.
	while (filterDec[0].size() > 0)
	{
		outputr = new FilterOutput<string>(outputr, 1);
		filterDec[0].pop_back();
	}
	while (filterDec[1].size() > 0)
	{
		outputr = new FilterOutput<string>(outputr, 2);
		filterDec[1].pop_back();
	}

		//process file line by line.
	outputDecoration(decInputFile, outputr);

	//end of program
	decInputFile.close();
	outputFile.close();
	KeepRunning kr;
	return 0;
}

//1
int fileInputPrompt(ifstream &decInputFile)
{
	cout << "Please Enter a file for reading.\n";
	string fileName = "";
	cin >> fileName;

	//input data file.
	decInputFile.open(fileName, ios::binary);
	if (!decInputFile.is_open() || !decInputFile)  // Did the open work?
	{
		cerr << "Can't open file for input!\n";
		return 1;
	}
	return 0;
}

int fileOutputPrompt(ofstream& outFile)
{
	cout << "Please Enter a file for Output (Must be a New File).\n";
	string fileName = "";
	cin >> fileName;

	//input data file.
	outFile.open(fileName, ios::binary);
	if (!outFile.is_open() || !outFile)  // Did the open work?
	{
		cerr << "Can't open file for output!\n";
		return 1;
	}
	return 0;
}

//2
std::vector<int> decorationsMenu(vector<int> &refTeeVector, vector<vector<int>> &refFilterVector)
{
	char menuInput = ' ';
	vector<int> decorationsVector;
	int teeCounter = 0;
	char filterInput = ' ';
	while (menuInput != '5')
	{
		cout << "Decorations Menu:\n";
		cout << "1.	LineOutput: adds a newline with every write.\n";
		cout << "2.	NumberedOutput: adds newlines and precedes each write with the current line number.\n";
		cout << "3.	TeeOutput : writes to two streams at a time.\n";
		cout << "4.	FilterOutput : writes only those objects that satisfy a certain condition.\n";
		cout << "5. Quit Decorations.\n";
		cin >> menuInput;
		switch (menuInput)
		{
			case '1':
				decorationsVector.push_back(1);
				break;
			case '2':
				decorationsVector.push_back(2);
				break;
			case '3':
				if (teeCounter <= 2)
					refTeeVector.push_back(3);
				if (teeCounter > 2)
					cout << "Only allowing Three TeeOutput Decorators. Choose Another Option.\n";
				teeCounter++;
				break;
			case '4':
				
				cout << "Choose a Unary Predicate for Filtered Decorator:\n";
				cout << "1. Contains Digit:		Line contains a digit.\n";
				cout << "2. Contains Hash Sign:		Line has a # in it.\n";
				cin >> filterInput;
				switch (filterInput)
				{
				case '1':
					refFilterVector[0].push_back(4);
					break;
				case '2':
					refFilterVector[1].push_back(4);
				}
				break;
			case '5':
				cout << "\nEnd of Decorations, let's check what we made!\n\n";
				break;
		}
	}
	return decorationsVector;
}

template<typename T>
Output<T>* processDecorations(vector<int> &vec, Output<T>* out)
{
	if (vec.size() > 0)
	{
		//process Line and Numbered Outputs.
		if (vec.size() > 0)
			while (vec.size() > 0)
			{
				if (vec.size() > 0 && vec.back() == 1)
				{
					out = new LineOutput<string>(out);
					vec.pop_back();
				}
				if (vec.size() > 0 && vec.back() == 2)
				{
					out = new NumberedOutput<string>(out);
					vec.pop_back();
				}
			}
	}
	return out;
}

template<typename T>
void outputDecoration(ifstream &decInputFile, Output<T>* out)
{
	string tempString = "";
	while (!decInputFile.eof())
	{
		//line by line.
		getline(decInputFile, tempString, '\n');
		tempString += '\n';
		out->write(tempString);
	}
	cout << "\nEnd of Decoration Output. Check Output File!\n";
}