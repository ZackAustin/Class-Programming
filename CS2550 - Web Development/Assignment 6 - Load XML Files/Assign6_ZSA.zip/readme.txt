Zack Austin
Assignment 6 - Load XML Data
11/22

I used XML files to display puzzles for my Sudoku game on the sudokuGame.html game grid page.

The XML files are in the "Puzzle Files" folder along with the associated DTD. The files need to be in that folder in order to be loaded correctly.

The default puzzle shown is "Easy Puzzle 1.xml". Change the drop down menus for difficulty and puzzle number on the game page and hit the new puzzle button for other puzzles.