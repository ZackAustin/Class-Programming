//Game Logic -- Controller Region

var sudoku = sudoku || {};
sudoku.sController = sudoku.sController || {};

sudoku.sController.getCellText = function(cell)
{
	var text = "";

	if (cell.classList.contains("userNum"))
		text = cell.lastChild.value;
	else text = cell.innerHTML;
	
	return text;
};

sudoku.sController.updateModel = function()
{
	var table = document.getElementById("generateSudokuBoard");
	//ensure up to date model.
	for (var i = 0; i < sudoku.ROWS; i++)
	{
		for (var j = 0; j < sudoku.COLUMNS; j++)
		{
			var gridCell = table.rows[i].cells[j];
			var text = "";
			if (gridCell.hasChildNodes() && gridCell.classList.contains("userNum"))
			{
				var cellsField = gridCell.lastChild;
				text = cellsField.value;
			}
			else text = gridCell.innerHTML;
			sudoku.sModel.model[i][j].text = text;
		}
	}
};

sudoku.sController.updateCell = function(cell, modelContents)
{
	cell.innerHTML = modelContents.text;
	
	if (modelContents.name == "predetNum")
	{
		if (!(cell.classList.contains("predetNum")))
			cell.classList.add("predetNum");
	}
	else if (modelContents.name == "userNum")
	{
		if (!(cell.classList.contains("userNum")))
			cell.classList.add("userNum");
	}
	//alert("cell contents are: " + cell.innerHTML + "\nmodels contents are: " + model.name + " " + model.text + "\n");
};

sudoku.sController.checkRow = function(model, cell, row, col)
{
	//check if other numbers on this row has this number.
	for (var i = 0; i < sudoku.COLUMNS; i++)
	{
		if (i != col)
		{
			var text = this.getCellText(cell);
			
			if (model[row][i].text == text && text != "")
			{
				//need to set the error classlist for cell if it isn't set.
				if ((!(cell.classList.contains("userError"))) && model[row][col].name == "userNum")
				{
					cell.classList.add("userError");
					var cellsField = cell.lastChild;
					cellsField.classList.add("userError");
					return false;
				}
			}
		}
	}
	return true;
};

sudoku.sController.checkColumn = function(model, cell, row, col)
{
	//check if other numbers on this column has this number.
	for (var j = 0; j < sudoku.ROWS; j++)
	{
		if (j != row)
		{
			var text = this.getCellText(cell);
			
			if (model[j][col].text == text && text != "")
			{
				//need to set the error classlist for cell if it isn't set.
				if ((!(cell.classList.contains("userError"))) && model[row][col].name == "userNum")
				{
					cell.classList.add("userError");
					var cellsField = cell.lastChild;
					cellsField.classList.add("userError");
					return false;
				}
			}
		}
	}
	return true;
};

sudoku.sController.createRowObject = function(row)
{
	//rowObject is a row-index ranged object.
	var rowStart = 0, rowEnd = 0;
	if (row == 0 || row  == 3 || row == 6)
	{
		rowStart = row;
		rowEnd = row + 2;
	}
	else if (row == 1 || row == 4 || row == 7)
	{
		rowStart = row - 1;
		rowEnd = row + 1;
	}
	else
	{
		rowStart = row - 2;
		rowEnd = row;
	}
	var rowObject =
	{
		rs: rowStart,
		re: rowEnd
	};
	return rowObject;
};

sudoku.sController.createColumnObject = function(col)
{
	//columnObject is a column-index ranged object.
	var colStart = 0, colEnd = 0;
	if (col == 0 || col  == 3 || col == 6)
	{
		colStart = col;
		colEnd = col + 2;
	}
	else if (col == 1 || col == 4 || col == 7)
	{
		colStart = col - 1;
		colEnd = col + 1;
	}
	else
	{
		colStart = col - 2;
		colEnd = col;
	}
	var colObject =
	{
		cs: colStart,
		ce: colEnd
	};
	return colObject;
};

sudoku.sController.createBlockObject = function(row, col)
{
	//blockObject represents index ranges for a specific 3x3 block-check against.
	var blockObject =
	{
		rowObject: this.createRowObject(row),
		colObject: this.createColumnObject(col)
	};
	return blockObject;
};

sudoku.sController.checkBlock = function(model, cell, row, col)
{
	var blockObject = this.createBlockObject(row, col);
	
	for (var i = blockObject.rowObject.rs; i <= blockObject.rowObject.re; i++)
	{
		for (var j = blockObject.colObject.cs; j <= blockObject.colObject.ce; j++)
		{
			if (i != row && j != col)
			{
				var text = this.getCellText(cell);
				
				if (model[i][j].text == text && text != "")
				{
					//need to set the error classlist for cell if it isn't set.
					if ((!(cell.classList.contains("userError"))) && model[row][col].name == "userNum")
					{
						cell.classList.add("userError");
						var cellsField = cell.lastChild;
						cellsField.classList.add("userError");
						return false;
					}
				}
			}
		}
	}
	return true;
};

sudoku.sController.checkCell = function(model, cell, row, col)
{
	//first unset the error.
	if (cell.classList.contains("userError"))
	{
		cell.classList.remove("userError");
		var cellsField = cell.lastChild;
		cellsField.classList.remove("userError");
	}
	
	//check the row
	var check = this.checkRow(model, cell, row, col);
	if (check == false)
		return false;
	else
	{
		//check the column
		check = this.checkColumn(model, cell, row, col);
		if (check == false)
			return false;
		else
		{
			//check the block, return check afterwards.
			return this.checkBlock(model, cell, row, col);
		}
	}
};

sudoku.sController.checkSolution = function()
{
	//check all cells
	var table = document.getElementById("generateSudokuBoard");
	var solutionObject = {
		solution: true,
		numberIncorrect: 0,
		numberCorrect: 0,
		wrongRow: [],
		wrongColumn: []
	};
	
	for (var q = 0; q < sudoku.ROWS; q++)
	{
		for (var w = 0; w < sudoku.COLUMNS; w++)
		{
			var gridCell = table.rows[q].cells[w];
			var check = this.checkCell(sudoku.sModel.model, gridCell, q, w);
			
			if (sudoku.sModel.model[q][w].name == "userNum")
			{
				gridCell.style.backgroundColor = "";
				var cellsField = gridCell.lastChild;
				cellsField.style.backgroundColor = "";
				
			}
			else gridCell.style.backgroundColor = "";
			
			if (check == false)
			{
				solutionObject.solution = false;
				solutionObject.wrongRow[solutionObject.numberIncorrect] = q;
				solutionObject.wrongColumn[solutionObject.numberIncorrect] = w;
				solutionObject.numberIncorrect += 1;
			}
			
			if (sudoku.sModel.model[q][w].text == "")
				solutionObject.numberCorrect += 1;
		}
	}
	return solutionObject;
};