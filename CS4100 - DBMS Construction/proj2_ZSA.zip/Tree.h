#include <array>
#include <iostream>
#include "Tuple.h"

const int MAXKEYS = 4;
const int MINKEYS = MAXKEYS / 2;

#pragma once
class BNode
{
public:
	virtual ~BNode() = 0;
	virtual void* Insert(int key, Tuple* data, int treeLevel) = 0;
	virtual void* Split(bool evenSplit) = 0;
	virtual void* Delete(BNode* currentNode, int key, int treeLevel, BNode* LN, BNode* RN, BNode* LA, BNode* RA, int LALevel, int RALevel) = 0;
	virtual void* Rebalance(BNode* currentNode, int key, int treeLevel, BNode* LN, BNode* RN, BNode* LA, BNode* RA, int LALevel, int RALevel) = 0;
	virtual void* Shift(BNode* ShiftNode, BNode* UnderflowNode, BNode* Anchor, bool left, int treeLevel, int pivotKey) = 0;
	virtual void* Merge(BNode* MergeNode, BNode* DeletedNode, BNode* Anchor, bool left, int treeLevel, int pivotKey) = 0;
	virtual BNode* getNode(int pos) = 0;
	virtual int minMax() = 0;
	virtual void TreeDump(int level) = 0;
	virtual void LeafDump(int level) = 0;
	virtual int getkey0() = 0;
	virtual int getNodeCnt() = 0;
	virtual int getKey(int pos) = 0;
	virtual void* getNodeData(int pos) = 0;
	virtual void setKey(int pos, int val) = 0;
	virtual void removeKeyPair(BNode* theNode, int pos) = 0;
	virtual void Next(BNode* nextNode) = 0;
	virtual BNode* getNext() = 0;
};

class DataNode : public BNode
{
	bool leftmostNode;
	int nodeCount;
	std::array<int, MAXKEYS> keys;
	std::array<Tuple*, MAXKEYS> tupleData;
	DataNode* next;
public:
	DataNode(bool leftmost);
	DataNode::DataNode(std::array<int, MAXKEYS / 2> &keyVals, std::array<Tuple*, MAXKEYS / 2> &recVals);
	~DataNode();
	void* Insert(int key, Tuple* data, int treeLevel);
	void* Split(bool evenSplit);
	void* Delete(BNode* currentNode, int key, int treeLevel, BNode* LN, BNode* RN, BNode* LA, BNode* RA, int LALevel, int RALevel);
	void* Rebalance(BNode* currentNode, int key, int treeLevel, BNode* LN, BNode* RN, BNode* LA, BNode* RA, int LALevel, int RALevel);
	void* Shift(BNode* ShiftNode, BNode* UnderflowNode, BNode* Anchor, bool left, int treeLevel, int pivotKey);
	void* Merge(BNode* MergeNode, BNode* DeletedNode, BNode* Anchor, bool left, int treeLevel, int pivotKey);
	void removeKeyPair(BNode* theNode, int pos);
	BNode* getNode(int pos) { return nullptr;} //noop
	int minMax();
	void TreeDump(int level);
	void LeafDump(int level);
	int getkey0();
	int getNodeCnt(){return this->nodeCount;}
	int getKey(int pos) {return keys[pos];}
	void* getNodeData(int pos) {return tupleData[pos];}
	void setKey(int pos, int val) {keys[pos] = val;}
	void Next(BNode* nextNode){this->next = (DataNode*)nextNode;}
	BNode* getNext(){return next;}
};

class IndexNode : public BNode
{
	int nodeCount;
	std::array <int, MAXKEYS> keys;
	std::array<BNode*, MAXKEYS + 1> nodePtrs;
public:
	IndexNode();
	IndexNode(BNode* minValNode, BNode* maxValNode, int minmax);
	~IndexNode();
	void* Insert(int key, Tuple* data, int treeLevel);
	void* Split(bool evenSplit);
	void* Delete(BNode* currentNode, int key, int treeLevel, BNode* LN, BNode* RN, BNode* LA, BNode* RA, int LALevel, int RALevel);
	void* Rebalance(BNode* currentNode, int key, int treeLevel, BNode* LN, BNode* RN, BNode* LA, BNode* RA, int LALevel, int RALevel);
	void* Shift(BNode* ShiftNode, BNode* UnderflowNode, BNode* Anchor, bool left, int treeLevel, int pivotKey);
	void* Merge(BNode* MergeNode, BNode* DeletedNode, BNode* Anchor, bool left, int treeLevel, int pivotKey);
	void removeKeyPair(BNode* theNode, int pos);
	BNode* getNode(int pos);
	int minMax();
	void TreeDump(int level);
	void LeafDump(int level);
	int getkey0();
	int getNodeCnt(){return this->nodeCount;}
	int getKey(int pos) {return keys[pos];}
	void* getNodeData(int pos) {return nodePtrs[pos];}
	void setKey(int pos, int val) {keys[pos] = val;}
	void Next(BNode* nextNode){}//noop
	BNode* getNext(){return nullptr;}//noop
};

struct nodeCompare
{
	bool operator() (BNode* t1, BNode* t2)
	{
		int tmp1 = std::numeric_limits<int>::max(), tmp2 = std::numeric_limits<int>::max();
		if (t1 != nullptr)
			tmp1 = t1->getkey0();
		if (t2 != nullptr)
			tmp2 = t2->getkey0();
		return (tmp1 < tmp2);
	}
};