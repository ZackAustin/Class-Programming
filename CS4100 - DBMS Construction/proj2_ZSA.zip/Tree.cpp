#include "Tree.h"
#include <string>

using namespace std;

BNode::~BNode(){}

DataNode::DataNode(bool leftmost) : leftmostNode(leftmost)
{
	next = nullptr;
	nodeCount = 0;
	for (size_t i = 0; i < keys.size(); i++)
	{
		keys[i] = numeric_limits<int>::max();
		tupleData[i] = nullptr;
	}
}

DataNode::DataNode(array<int, MAXKEYS / 2> &keyVals, array<Tuple*, MAXKEYS / 2> &recVals)
{
	next = nullptr;
	nodeCount = 2;
	leftmostNode = false;
	for (size_t i = 0; i < keys.size(); i++)
	{
		keys[i] = numeric_limits<int>::max();
		tupleData[i] = nullptr;
	}

	for (int i = 0; i < MAXKEYS / 2; i++)
	{
		keys[i] = keyVals[i];
		tupleData[i] = recVals[i];
	}
}

DataNode::~DataNode()
{
	//cout << "\ndeleting a leaf node with keys: ";
	for (int i = 0; i < nodeCount; i++)
	{
		delete tupleData[i];
		tupleData[i] = nullptr;
		//cout << keys[i] << ", ";
	}
}

void* DataNode::Insert(int key, Tuple* data, int treeLevel)
{
	//split datanode
	if (nodeCount == MAXKEYS)
	{
		DataNode* maxValNode = (DataNode*) DataNode::Split(true);
		maxValNode->next = this->next;
		this->next = maxValNode;

		int minMax = maxValNode->keys[0];
		if (key < minMax)
		{
			this->keys[nodeCount] = key;
			this->tupleData[nodeCount++] = data;
			sort(keys.begin(), keys.end());
			sort(tupleData.begin(), tupleData.end(), tupCompare());
		}
		else
		{
			maxValNode->Insert(key, data, 0);
		}

		//if root split
		if (treeLevel == 0)
		{
			IndexNode* newRoot = new IndexNode(this, maxValNode, maxValNode->keys[0]);
			return newRoot;
		}

		return maxValNode;
	}

	//data node Insert
	if (nodeCount < MAXKEYS)
	{
		keys[nodeCount] = key;
		tupleData[nodeCount++] = data;

		sort(keys.begin(), keys.end());
		sort(tupleData.begin(), tupleData.end(), tupCompare());

		return nullptr;
	}
	return this;
}

void* DataNode::Split(bool evenSplit)
{
	std::array<int, MAXKEYS / 2> tmpKeys;
	std::array<Tuple*, MAXKEYS / 2> tmpRecords;
	for (int i = 0; i < MAXKEYS / 2; i++)
	{
		tmpKeys[i] = keys[MAXKEYS / 2 + i];
		tmpRecords[i] = tupleData[MAXKEYS / 2 + i];
	}

	DataNode* maxValueNode = new DataNode(tmpKeys, tmpRecords);
	
	for (size_t i = 0; i < keys.size() / 2; i++)
	{
		keys[MAXKEYS / 2 + i] = numeric_limits<int>::max();
		tupleData[MAXKEYS / 2 + i] = nullptr;
	}
	nodeCount = 2;

	return maxValueNode;
}

void* DataNode::Delete(BNode* currentNode, int key, int treeLevel, BNode* LN, BNode* RN, BNode* LA, BNode* RA, int LALevel, int RALevel)
{
	for (int i = 0; i < nodeCount; i++)
	{
		if (keys[i] == key)
		{
			keys[i] = numeric_limits<int>::max();
			delete tupleData[i];
			tupleData[i] = nullptr;
			nodeCount--;
			sort(keys.begin(), keys.end());
			sort(tupleData.begin(), tupleData.end(), tupCompare());
		}
	}

	//check for a rebalance.
	if (treeLevel != 0  && nodeCount < MINKEYS)
	{
		this->Rebalance(currentNode, key, treeLevel, LN, RN, LA, RA, LALevel, RALevel);
	}

	return this;
}

void* DataNode::Rebalance(BNode* currentNode, int key, int treeLevel, BNode* LN, BNode* RN, BNode* LA, BNode* RA, int LALevel, int RALevel)
{
	
	int LNSize = -1, RNSize = -1;

	if (LN != nullptr)
		LNSize = LN->getNodeCnt();
	if (RN != nullptr)
		RNSize = RN->getNodeCnt();

//	Shift LR if the left neighbor size > right neighbor size and left neighbor size > 
//minKeys 
//or 
//if the right neighbor size > minKeys and left neighbor size > minKeys and 
//left anchor level > right anchor level. 

	if ((LNSize > RNSize && LNSize > (MAXKEYS / 2)) || (RNSize > (MAXKEYS / 2) && LNSize > (MAXKEYS / 2) && LALevel > RALevel))
	{
		//SHIFT LR, uses LN, this, LA.
		//find pivotkey.
		
		int tmpPivot = -1;
		for (int i = 0; i < LA->getNodeCnt(); i++)
		{
			if (LA->getKey(i) > LN->getKey(LN->getNodeCnt() - 1) && LA->getKey(i) <= this->keys[0])
			{
				tmpPivot = i;
			}
		}

		this->Shift(LN, this, LA, true, treeLevel, tmpPivot);
	}

	//Shift RL if the right neighbor size > left neighbor size and right neighbor size > minKeys 
	//or 
	//if the right neighbor size > minKeys and left neighbor size > minKeys and 
	//right anchor level >= left anchor level. 

	else if ((RNSize > LNSize && RNSize > MINKEYS) || (RNSize > MINKEYS && LNSize > MINKEYS && RALevel >= LALevel))
	{
		//SHIFT RL, uses RN, this, RA.
		//find pivot key.

		int tmpPivot = -1;
		for (int i = 0; i < RA->getNodeCnt(); i++)
		{
			if (RA->getKey(i) > this->getKey(this->getNodeCnt() - 1) && RA->getKey(i) <= RN->getKey(0))
			{
				tmpPivot = i;
			}
		}
		this->Shift(RN, this, RA, false, treeLevel, tmpPivot);
	}

//Merge Left When Merging always picks the neighbor with the closest anchor� 
//if both the left neighbor and right neighbor == minKeys and left anchor 
//level > right anchor level 
//or 
//if the current node has no right neighbor because it is rightmost in the B+ 
//Tree and the left neighbor == minKeys. 

	else if ((LNSize == MINKEYS && RNSize == MINKEYS && LALevel > RALevel) || (RN == nullptr && LNSize == MINKEYS))
	{
		//MERGE LEFT,  uses LN, this, LA.
		//find pivot key.

		int tmpPivot = -1;
		for (int i = 0; i < LA->getNodeCnt(); i++)
		{
			if (LA->getKey(i) > LN->getKey(LN->getNodeCnt() - 1) && LA->getKey(i) <= this->getKey(0))
			{
				tmpPivot = i;
			}
		}
		this->Merge(LN, this, LA, true, treeLevel, tmpPivot);
	}



//Merge Right When Merging always picks the neighbor with the closest anchor� 
//if both the left neighbor and right neighbor == minKeys and right anchor 
//level >= left anchor level 
//or 
//if the current node has no left neighbor because it is leftmost in the B+ 
//Tree and the right neighbor == minKeys. 

	else
	{
		//MERGE RIGHT,  uses this, RN, RA.
		//find pivot key.

		int tmpPivot = -1;
		for (int i = 0; i < RA->getNodeCnt(); i++)
		{
			if (RA->getKey(i) > this->getKey(this->getNodeCnt() - 1) && RA->getKey(i) <= RN->getKey(0))
			{
				tmpPivot = i;
			}
		}

		this->Merge(this, RN, RA, false, treeLevel, tmpPivot);
	}




	return this;
}

void* DataNode::Shift(BNode* ShiftNode, BNode* UnderflowNode, BNode* Anchor, bool left, int treeLevel, int pivotKey)
{
	DataNode* tmp = (DataNode*)ShiftNode;

	if (left) //shift LR, UnderflowNode aka this aka current, grabs minmax to anchor pivot key.
	{
		UnderflowNode->Insert(tmp->keys[tmp->nodeCount - 1],tmp->tupleData[tmp->nodeCount - 1], treeLevel);
		this->removeKeyPair(ShiftNode, ShiftNode->getNodeCnt() - 1);
		Anchor->setKey(pivotKey, UnderflowNode->minMax());
	}
	else //shift RL, ShiftNode aka Right Neighbor, grabs minmax to anchor pivot key.
	{
		UnderflowNode->Insert(tmp->keys[0],tmp->tupleData[0], treeLevel);
		this->removeKeyPair(ShiftNode, 0);
		Anchor->setKey(pivotKey, ShiftNode->minMax());
	}

	return this;
}

void* DataNode::Merge(BNode* MergeNode, BNode* DeletedNode, BNode* Anchor, bool left, int treeLevel, int pivotKey)
{
	DataNode* tmp = (DataNode*)DeletedNode;
		//data into merge node.
		int tmpCnt = DeletedNode->getNodeCnt();
		for (int i = 0; i < tmpCnt; i++)
		{
			//Tuple* tmpTup = new Tuple(tmp->keys[i]);
			MergeNode->Insert(tmp->keys[i], tmp->tupleData[i], treeLevel);
			//this->removeKeyPair(DeletedNode, i);
		}
		MergeNode->Next(DeletedNode->getNext());
		Anchor->removeKeyPair(Anchor, pivotKey);

	return this;
}

void DataNode::removeKeyPair(BNode* theNode, int pos)
{
	DataNode* tmp = (DataNode*)theNode;
	tmp->keys[pos] = numeric_limits<int>::max();
	tmp->tupleData[pos] = nullptr;
	tmp->nodeCount--;
	sort(tmp->keys.begin(), tmp->keys.end());
	sort(tmp->tupleData.begin(), tmp->tupleData.end(), tupCompare());
}

int DataNode::minMax(){return this->keys[0];}

void DataNode::TreeDump(int level)
{
	if (level == 0)
		cout << "\nDump of B+Tree\n";

	string indent = "";

	for (int z = 0; z < level; z++)
		indent += "\t";

	cout << indent << "[ ";

	for (int i = 0; i < nodeCount - 1; i++)
	{
		cout << tupleData[i]->getKey() << ", ";
	}
	if (nodeCount > 0)
		cout << tupleData[nodeCount - 1]->getKey() << " ]\n";
	else
		cout << " ]\n";
}

void DataNode::LeafDump(int level)
{
	if (level == 0)
		cout << "\nLeaves of B+Tree\n";
	cout << "\t[ ";
	for (int i = 0; i < nodeCount - 1; i++)
	{
		cout << this->tupleData[i]->getKey() << ", ";
	}
	if (nodeCount > 0)
		cout << this->tupleData[nodeCount - 1]->getKey() << " ]";
	else
		cout << " ]";
	if (this->next != nullptr)
	{
		cout << ",\n";
		next->LeafDump(level);
	}
	else
		cout << ".\n";
}

int DataNode::getkey0()
{
	return keys[0];
}

IndexNode::IndexNode()
{
	for (size_t i = 0; i < keys.size(); i++)
	{
		keys[i] = numeric_limits<int>::max();
		nodePtrs[i] = nullptr;
	}
	nodePtrs.back() = nullptr;
}

IndexNode::IndexNode(BNode* minValNode, BNode* maxValNode, int minmax)
{
	for (size_t i = 0; i < keys.size(); i++)
	{
		keys[i] = numeric_limits<int>::max();
		nodePtrs[i] = nullptr;
	}
	nodePtrs.back() = nullptr;

	nodeCount = 1;
	keys[0] = maxValNode->minMax();
	nodePtrs[0] = minValNode;
	nodePtrs[1] = maxValNode;
}

IndexNode::~IndexNode()
{
	//cout << "first delete for this index\n";
	for (size_t i = 0; i < nodePtrs.size(); i++)
	{
		if (nodePtrs[i] != nullptr)
		{
			delete nodePtrs[i];
			nodePtrs[i] = nullptr;
		}
	}
	//cout << "\nlast delete for this index";
}

void* IndexNode::Insert(int key, Tuple* data, int treeLevel)
{
	bool foundKey = false;
	int i = 0;
	BNode* splitNode = nullptr;
	while (foundKey == false)
	{
		if (key == this->keys[i])
		{
			splitNode = (BNode*)this->nodePtrs[i + 1]->Insert(key, data, treeLevel + 1);
			foundKey = true;
		}
		else if (key < this->keys[i])
		{
			splitNode = (BNode*)this->nodePtrs[i]->Insert(key, data, treeLevel + 1);
			foundKey = true;
		}
		else if (key > this->keys[nodeCount - 1])
		{
			splitNode = (BNode*)this->nodePtrs[nodeCount]->Insert(key, data, treeLevel + 1);
			foundKey = true;
		}
		i++;
	}

	i--;

	if (splitNode != nullptr)
	{
		bool splitType = true;
		if (nodeCount < MAXKEYS)
		{
			keys[nodeCount] = splitNode->minMax();
			nodePtrs[nodeCount + 1] = splitNode;

			sort(keys.begin(), keys.end());
			sort(nodePtrs.begin(), nodePtrs.end(), nodeCompare());
			nodeCount++;

			return nullptr;
		}
		else if (nodeCount == MAXKEYS)
		{
			bool evenSplit;
			if (key < keys[MINKEYS - 1]){/*inserting into minValNode.*/evenSplit = false; }
			else if (key >= keys[MINKEYS - 1]){evenSplit = true;}
			
			IndexNode* maxValNode = (IndexNode*) Split(evenSplit);

			if (evenSplit == false)
			{
				keys[nodeCount] = splitNode->minMax();
				nodePtrs[nodeCount + 1] = splitNode;
				
				sort(keys.begin(), keys.end());
				sort(nodePtrs.begin(), nodePtrs.end(), nodeCompare());

				nodeCount++;
			}
			else if (evenSplit == true)
			{
				maxValNode->keys[maxValNode->nodeCount] = splitNode->minMax();
				maxValNode->nodePtrs[maxValNode->nodeCount + 1] = splitNode;

				sort(maxValNode->keys.begin(), maxValNode->keys.end());
				sort(maxValNode->nodePtrs.begin(), maxValNode->nodePtrs.end(), nodeCompare());

				maxValNode->nodeCount += 1;
			}

			//HERE//

			//if root split
			if (treeLevel == 0)
			{
				IndexNode* newRoot = new IndexNode(this, maxValNode, maxValNode->keys[0]);
				return newRoot;
			}

			return maxValNode;
		}
	}

	return nullptr;
}

void* IndexNode::Split(bool evenSplit)
{
	IndexNode* maxValueNode = new IndexNode();
	int splitAmt = MAXKEYS / 2;
	if (evenSplit == false)
	{
		//uneven split, adding to minVal node. 1 in original, 3 in maxVal.
		for (int i = 0; i <= splitAmt; i++)
		{
			maxValueNode->keys[i] = this->keys[splitAmt + i - 1];
			maxValueNode->nodePtrs[i + 1] = this->nodePtrs[splitAmt + i];
		}
		maxValueNode->nodeCount = 3;
	}
	else if (evenSplit == true)
	{
		//even split, adding to maxVal node. 2 in orginial, 2 in maxVal.
		for (int i = 0; i < splitAmt; i++)
		{
			maxValueNode->keys[i] = this->keys[splitAmt + i];
			maxValueNode->nodePtrs[i + 1] = this->nodePtrs[splitAmt + i + 1];
		}
		maxValueNode->nodeCount = 2;
	}

	nodeCount = 2;

	if (evenSplit == false)
	{
		nodeCount--;
		//removing 1 more from minValNode since uneven split.
		this->keys[splitAmt - 1] = numeric_limits<int>::max();
		this->nodePtrs[splitAmt] = nullptr;
	}
		//remove 2 keys and nodes from minValNode.
		for (int i = 0; i < splitAmt; i++)
		{
			this->keys[i + splitAmt] = numeric_limits<int>::max();
			this->nodePtrs[i + splitAmt + 1] = nullptr;
		}	

	return maxValueNode;
}

void* IndexNode::Delete(BNode* currentNode, int key, int treeLevel, BNode* LN, BNode* RN, BNode* LA, BNode* RA, int LALevel, int RALevel)
{
	int i = 1;
	if (key < this->keys[0]) //next node leftmost node
	{
		BNode* tmpLN = nullptr;
		if (LN != nullptr)
			tmpLN = LN->getNode(LN->getNodeCnt());
		nodePtrs[0]->Delete(nodePtrs[0], key, treeLevel + 1, tmpLN, nodePtrs[1], LA, this, LALevel, RALevel + 1); 
	}
	else if (key >= this->keys[nodeCount - 1]) //next node rightmost node
	{
		BNode* tmpLN = nullptr;
		if (RN != nullptr)
			tmpLN = RN->getNode(0);
		nodePtrs[nodeCount]->Delete(nodePtrs[nodeCount], key, treeLevel + 1, nodePtrs[nodeCount - 1], tmpLN, this, RA, LALevel + 1, RALevel);
	}
	else //next node is a middle node
	{
		bool foundKey = false;
		while (foundKey == false && i < MAXKEYS)
		{
			if (key < this->keys[i])
			{
				nodePtrs[i]->Delete(nodePtrs[i], key, treeLevel + 1, nodePtrs[i - 1], nodePtrs[i + 1], this, this, treeLevel, treeLevel);
				foundKey = true;
			}

			i++;
		}
		i--;
	}

	//check for a rebalance.
	if (treeLevel != 0  && nodeCount < MAXKEYS / 2)
	{
		this->Rebalance(currentNode, key, treeLevel, LN, RN, LA, RA, LALevel, RALevel);
	}

	if (treeLevel == 0 && nodeCount == 0)
	{
		return nodePtrs[0];
	}

	return this;
}

void* IndexNode::Rebalance(BNode* currentNode, int key, int treeLevel, BNode* LN, BNode* RN, BNode* LA, BNode* RA, int LALevel, int RALevel)
{
	int LNSize = -1, RNSize = -1;

	if (LN != nullptr)
		LNSize = LN->getNodeCnt();
	if (RN != nullptr)
		RNSize = RN->getNodeCnt();

//	Shift LR if the left neighbor size > right neighbor size and left neighbor size > 
//minKeys 
//or 
//if the right neighbor size > minKeys and left neighbor size > minKeys and 
//left anchor level > right anchor level. 

	if ((LNSize > RNSize && LNSize > (MAXKEYS / 2)) || (RNSize > (MAXKEYS / 2) && LNSize > (MAXKEYS / 2) && LALevel > RALevel))
	{
		//SHIFT LR, uses LN, this, LA.
		//find pivotkey.
		
		int tmpPivot = -1;
		for (int i = 0; i < LA->getNodeCnt(); i++)
		{
			if (LA->getKey(i) > LN->getKey(LN->getNodeCnt() - 1) && LA->getKey(i) <= this->keys[0])
			{
				tmpPivot = i;
			}
		}
		this->Shift(LN, this, LA, true, treeLevel, tmpPivot);
	}

	//Shift RL if the right neighbor size > left neighbor size and right neighbor size > minKeys 
	//or 
	//if the right neighbor size > minKeys and left neighbor size > minKeys and 
	//right anchor level >= left anchor level. 

	else if ((RNSize > LNSize && RNSize > MINKEYS) || (RNSize > MINKEYS && LNSize > MINKEYS && RALevel >= LALevel))
	{
		//SHIFT RL, uses RN, this, RA.
		//find pivot key.

		int tmpPivot = -1;
		for (int i = 0; i < RA->getNodeCnt(); i++)
		{
			if (RA->getKey(i) > this->getKey(this->getNodeCnt() - 1) && RA->getKey(i) <= RN->getKey(0))
			{
				tmpPivot = i;
			}
		}
		this->Shift(RN, this, RA, false, treeLevel, tmpPivot);
	}

//Merge Left When Merging always picks the neighbor with the closest anchor� 
//if both the left neighbor and right neighbor == minKeys and left anchor 
//level > right anchor level 
//or 
//if the current node has no right neighbor because it is rightmost in the B+ 
//Tree and the left neighbor == minKeys. 

	else if ((LNSize == MINKEYS && RNSize == MINKEYS && LALevel > RALevel) || (RN == nullptr && LNSize == MINKEYS))
	{
		//MERGE LEFT,  uses LN, this, LA.
		//find pivot key.

		int tmpPivot = -1;
		for (int i = 0; i < LA->getNodeCnt(); i++)
		{
			if (LA->getKey(i) > LN->getKey(LN->getNodeCnt() - 1) && LA->getKey(i) <= this->getKey(0))
			{
				tmpPivot = i;
			}
		}
		this->Merge(LN, this, LA, true, treeLevel, tmpPivot);
	}

//Merge Right When Merging always picks the neighbor with the closest anchor� 
//if both the left neighbor and right neighbor == minKeys and right anchor 
//level >= left anchor level 
//or 
//if the current node has no left neighbor because it is leftmost in the B+ 
//Tree and the right neighbor == minKeys. 

	else
	{
		//MERGE RIGHT,  uses this, RN, RA.
		//find pivot key.

		int tmpPivot = -1;
		for (int i = 0; i < RA->getNodeCnt(); i++)
		{
			if (RA->getKey(i) > this->getKey(this->getNodeCnt() - 1) && RA->getKey(i) <= RN->getKey(0))
			{
				tmpPivot = i;
			}
		}

		this->Merge(this, RN, RA, false, treeLevel, tmpPivot);
	}

	return this;
}

void* IndexNode::Shift(BNode* ShiftNode, BNode* UnderflowNode, BNode* Anchor, bool left, int treeLevel, int pivotKey)
{
	IndexNode* tmpShift = (IndexNode*) ShiftNode;
	if (left) //SHIFT LR
	{
		IndexNode* tmpUnder = (IndexNode*) UnderflowNode;
		tmpUnder->keys[tmpUnder->nodeCount] = Anchor->getKey(pivotKey);
		tmpUnder->nodePtrs[tmpUnder->nodeCount + 1] = tmpShift->nodePtrs[tmpShift->nodeCount];
		Anchor->setKey(pivotKey, tmpShift->keys[tmpShift->nodeCount - 1]);
		tmpUnder->nodeCount++;
		sort(tmpUnder->keys.begin(), tmpUnder->keys.end());
		sort(tmpUnder->nodePtrs.begin(), tmpUnder->nodePtrs.end(), nodeCompare());
		tmpShift->keys[tmpShift->nodeCount - 1] = numeric_limits<int>::max();
		tmpShift->nodePtrs[tmpShift->nodeCount] = nullptr;
		tmpShift->nodeCount--;
		sort(tmpShift->keys.begin(), tmpShift->keys.end());
		sort(tmpShift->nodePtrs.begin(), tmpShift->nodePtrs.end(), nodeCompare());
	}
	else // SHIFT RL
	{
		IndexNode* tmpUnder = (IndexNode*) UnderflowNode;
		tmpUnder->keys[tmpUnder->nodeCount] = Anchor->getKey(pivotKey);
		tmpUnder->nodePtrs[tmpUnder->nodeCount + 1] = tmpShift->nodePtrs[0];
		Anchor->setKey(pivotKey, tmpShift->keys[0]);
		tmpUnder->nodeCount++;
		sort(tmpUnder->keys.begin(), tmpUnder->keys.end());
		sort(tmpUnder->nodePtrs.begin(), tmpUnder->nodePtrs.end(), nodeCompare());
		tmpShift->keys[0] = numeric_limits<int>::max();
		tmpShift->nodePtrs[0] = nullptr;
		tmpShift->nodeCount--;
		sort(tmpShift->keys.begin(), tmpShift->keys.end());
		sort(tmpShift->nodePtrs.begin(), tmpShift->nodePtrs.end(), nodeCompare());
	}

	return this;
}

void* IndexNode::Merge(BNode* MergeNode, BNode* DeletedNode, BNode* Anchor, bool left, int treeLevel, int pivotKey)
{
	IndexNode* tmpDeleted = (IndexNode*)DeletedNode;
	IndexNode* tmpMerge = (IndexNode*)MergeNode;
		int tmpCnt =  DeletedNode->getNodeCnt();
		for (int i = 0; i < tmpCnt; i++)
		{
			tmpMerge->keys[tmpMerge->nodeCount] = tmpDeleted->keys[i];
			tmpMerge->nodePtrs[tmpMerge->nodeCount + 1] = tmpDeleted->nodePtrs[i];
			tmpMerge->nodeCount++;
			sort(tmpMerge->keys.begin(), tmpMerge->keys.end());
			sort(tmpMerge->nodePtrs.begin(), tmpMerge->nodePtrs.end(), nodeCompare());

		}
		tmpMerge->keys[tmpMerge->nodeCount] = Anchor->getKey(pivotKey);
		tmpMerge->nodePtrs[tmpMerge->nodeCount + 1] = tmpDeleted->nodePtrs[tmpDeleted->nodeCount];
		tmpMerge->nodeCount++;
		sort(tmpMerge->keys.begin(), tmpMerge->keys.end());
		sort(tmpMerge->nodePtrs.begin(), tmpMerge->nodePtrs.end(), nodeCompare());

		Anchor->removeKeyPair(Anchor, pivotKey);

	return this;
}

void IndexNode::removeKeyPair(BNode* theNode, int pos)
{
	IndexNode* tmp = (IndexNode*)theNode;
	tmp->keys[pos] = numeric_limits<int>::max();
	//delete tmp->nodePtrs[pos + 1];
	tmp->nodePtrs[pos + 1] = nullptr;
	tmp->nodeCount--;
	sort(tmp->keys.begin(), tmp->keys.end());
	sort(tmp->nodePtrs.begin(), tmp->nodePtrs.end(), nodeCompare());
}

BNode* IndexNode::getNode(int pos)
{
	return this->nodePtrs[pos];
}

int IndexNode::minMax()
{
	auto key = this->keys[0];
	this->keys[0] = numeric_limits<int>::max();
	nodeCount--;

	bool evenSplit = false;

	if (nodePtrs[0] == nullptr)
		evenSplit = true;

	for (int i = 0; i <= nodeCount; i++)
	{
		keys[i] = keys[i + 1];
		if (evenSplit)
			nodePtrs[i] = nodePtrs[i + 1]; //only adjust nodeptrs on uneven splits
	}

	for (unsigned int i = 0; i < keys.size() - nodeCount; i++)
	{
		keys[nodeCount + i] = numeric_limits<int>::max();
		nodePtrs[nodeCount + 1 + i] = nullptr;
	}

	return key;
}

void IndexNode::TreeDump(int level)
{
	if (level == 0)
		cout << "\nDump of B+Tree\n";

	string indent = "";

	for (int z = 0; z < level; z++)
	{
		indent += "\t";
	}

	cout << indent << "( *, ";
	for (int j = 0; j < nodeCount; j++)
	{
		cout << this->keys[j] << " *, ";
	}

	cout << ")\n";

	for (int i = 0; i <= nodeCount; i++)
	{
		nodePtrs[i]->TreeDump(level + 1);
	}
}

void IndexNode::LeafDump(int level)
{
	if (level == 0)
		cout << "\nLeaves of B+Tree\n";

	nodePtrs[0]->LeafDump(level + 1);
}

int IndexNode::getkey0()
{
	return keys[0];
}