#pragma once
#include <algorithm>
#include <limits>

class Tuple
{
	int _key;
public:
	Tuple(int key);
	int getKey(){ return _key; }
	~Tuple();
};

struct tupCompare
{
	bool operator() (Tuple* t1, Tuple* t2)
	{
		int tmp1 = std::numeric_limits<int>::max(), tmp2 = std::numeric_limits<int>::max();
		if (t1 != nullptr)
			tmp1 = t1->getKey();
		if (t2 != nullptr)
			tmp2 = t2->getKey();
		return (tmp1 < tmp2); 
	}
};