#include "Tree.h"
#include <string>

using namespace std;

BNode::~BNode() = default;

DataNode::DataNode(bool leftmost) : leftmostNode(leftmost)
{
	next = nullptr;
	nodeCount = 0;
	for (size_t i = 0; i < keys.size(); i++)
	{
		keys[i] = numeric_limits<int>::max();
		tupleData[i] = nullptr;
	}
}

DataNode::DataNode(array<int, MAXKEYS / 2> &keyVals, array<Tuple*, MAXKEYS / 2> &recVals)
{
	next = nullptr;
	nodeCount = 2;
	leftmostNode = false;
	for (size_t i = 0; i < keys.size(); i++)
	{
		keys[i] = numeric_limits<int>::max();
		tupleData[i] = nullptr;
	}

	for (int i = 0; i < MAXKEYS / 2; i++)
	{
		keys[i] = keyVals[i];
		tupleData[i] = recVals[i];
	}
}

DataNode::~DataNode()
{
	//cout << "\ndeleting a leaf node with keys: ";
	for (int i = 0; i < nodeCount; i++)
	{
		delete tupleData[i];
		tupleData[i] = nullptr;
		//cout << keys[i] << ", ";
	}
}

void* DataNode::insert(int key, Tuple* data, int treeLevel)
{
	//split datanode
	if (nodeCount == MAXKEYS)
	{
		DataNode* maxValNode = (DataNode*) DataNode::split(true);
		maxValNode->next = this->next;
		this->next = maxValNode;

		int minMax = maxValNode->keys[0];
		if (key < minMax)
		{
			this->keys[nodeCount] = key;
			this->tupleData[nodeCount++] = data;
			sort(keys.begin(), keys.end());
			sort(tupleData.begin(), tupleData.end(), tupCompare());
		}
		else
		{
			maxValNode->insert(key, data, 0);
		}

		//if root split
		if (treeLevel == 0)
		{
			IndexNode* newRoot = new IndexNode(this, maxValNode, maxValNode->keys[0]);
			return newRoot;
		}

		return maxValNode;
	}

	//data node insert
	if ((nodeCount >= MINKEYS && nodeCount < MAXKEYS) || treeLevel == 0 && nodeCount < MAXKEYS)
	{
		keys[nodeCount] = key;
		tupleData[nodeCount++] = data;

		sort(keys.begin(), keys.end());
		sort(tupleData.begin(), tupleData.end(), tupCompare());

		return nullptr;
	}
	return this;
}

void* DataNode::split(bool evenSplit)
{
	std::array<int, MAXKEYS / 2> tmpKeys;
	std::array<Tuple*, MAXKEYS / 2> tmpRecords;
	for (int i = 0; i < MAXKEYS / 2; i++)
	{
		tmpKeys[i] = keys[MAXKEYS / 2 + i];
		tmpRecords[i] = tupleData[MAXKEYS / 2 + i];
	}

	DataNode* maxValueNode = new DataNode(tmpKeys, tmpRecords);
	
	for (size_t i = 0; i < keys.size() / 2; i++)
	{
		keys[MAXKEYS / 2 + i] = numeric_limits<int>::max();
		tupleData[MAXKEYS / 2 + i] = nullptr;
	}
	nodeCount = 2;

	return maxValueNode;
}

int DataNode::minMax()
{
	return this->keys[0];
}

void DataNode::TreeDump(int level)
{
	if (level == 0)
		cout << "\nDump of B+Tree\n";

	string indent = "";

	for (int z = 0; z < level; z++)
		indent += "\t";

	cout << indent << "[ ";

	for (int i = 0; i < nodeCount - 1; i++)
	{
		cout << tupleData[i]->getKey() << ", ";
	}

	cout << tupleData[nodeCount - 1]->getKey() << " ]\n";
}

void DataNode::LeafDump(int level)
{
	cout << "\t[ ";
	for (int i = 0; i < nodeCount - 1; i++)
	{
		cout << this->tupleData[i]->getKey() << ", ";
	}
	cout << this->tupleData[nodeCount - 1]->getKey() << " ]";
	if (this->next != nullptr)
	{
		cout << ",\n";
		next->LeafDump(level);
	}
	else
		cout << ".\n";
}

int DataNode::getkey0()
{
	return keys[0];
}

IndexNode::IndexNode()
{
	for (size_t i = 0; i < keys.size(); i++)
	{
		keys[i] = numeric_limits<int>::max();
		nodePtrs[i] = nullptr;
	}
	nodePtrs.back() = nullptr;
}

IndexNode::IndexNode(BNode* minValNode, BNode* maxValNode, int minmax)
{
	for (size_t i = 0; i < keys.size(); i++)
	{
		keys[i] = numeric_limits<int>::max();
		nodePtrs[i] = nullptr;
	}
	nodePtrs.back() = nullptr;

	nodeCount = 1;
	keys[0] = maxValNode->minMax();
	nodePtrs[0] = minValNode;
	nodePtrs[1] = maxValNode;
}

IndexNode::~IndexNode()
{
	//cout << "first delete for this index\n";
	for (size_t i = 0; i < nodePtrs.size(); i++)
	{
		if (nodePtrs[i] != nullptr)
		{
			delete nodePtrs[i];
			nodePtrs[i] = nullptr;
		}
	}
	//cout << "\nlast delete for this index";
}

void* IndexNode::insert(int key, Tuple* data, int treeLevel)
{
	bool foundKey = false;
	int i = 0;
	BNode* splitNode = nullptr;
	while (foundKey == false)
	{
		if (key == this->keys[i])
		{
			splitNode = (BNode*)this->nodePtrs[i + 1]->insert(key, data, treeLevel + 1);
			foundKey = true;
		}
		else if (key < this->keys[i])
		{
			splitNode = (BNode*)this->nodePtrs[i]->insert(key, data, treeLevel + 1);
			foundKey = true;
		}
		else if (key > this->keys[nodeCount - 1])
		{
			splitNode = (BNode*)this->nodePtrs[nodeCount]->insert(key, data, treeLevel + 1);
			foundKey = true;
		}
		i++;
	}

	i--;

	if (splitNode != nullptr)
	{
		bool splitType = true;
		if (nodeCount < MAXKEYS)
		{
			keys[nodeCount] = splitNode->minMax();
			nodePtrs[nodeCount + 1] = splitNode;

			sort(keys.begin(), keys.end());
			sort(nodePtrs.begin(), nodePtrs.end(), nodeCompare());
			nodeCount++;

			return nullptr;
		}
		else if (nodeCount == MAXKEYS)
		{
			bool evenSplit;
			if (key < keys[MINKEYS - 1]){/*inserting into minValNode.*/evenSplit = false; }
			else if (key >= keys[MINKEYS - 1]){evenSplit = true;}
			
			IndexNode* maxValNode = (IndexNode*) split(evenSplit);

			if (evenSplit == false)
			{
				keys[nodeCount] = splitNode->minMax();
				nodePtrs[nodeCount + 1] = splitNode;
				
				sort(keys.begin(), keys.end());
				sort(nodePtrs.begin(), nodePtrs.end(), nodeCompare());

				nodeCount++;
			}
			else if (evenSplit == true)
			{
				maxValNode->keys[maxValNode->nodeCount] = splitNode->minMax();
				maxValNode->nodePtrs[maxValNode->nodeCount + 1] = splitNode;

				sort(maxValNode->keys.begin(), maxValNode->keys.end());
				sort(maxValNode->nodePtrs.begin(), maxValNode->nodePtrs.end(), nodeCompare());

				maxValNode->nodeCount += 1;
			}

			//HERE//

			//if root split
			if (treeLevel == 0)
			{
				IndexNode* newRoot = new IndexNode(this, maxValNode, maxValNode->keys[0]);
				return newRoot;
			}

			return maxValNode;
		}
	}

	return nullptr;
}

void* IndexNode::split(bool evenSplit)
{
	IndexNode* maxValueNode = new IndexNode();
	int splitAmt = MAXKEYS / 2;
	if (evenSplit == false)
	{
		//uneven split, adding to minVal node. 1 in original, 3 in maxVal.
		for (int i = 0; i <= splitAmt; i++)
		{
			maxValueNode->keys[i] = this->keys[splitAmt + i - 1];
			maxValueNode->nodePtrs[i + 1] = this->nodePtrs[splitAmt + i];
		}
		maxValueNode->nodeCount = 3;
	}
	else if (evenSplit == true)
	{
		//even split, adding to maxVal node. 2 in orginial, 2 in maxVal.
		for (int i = 0; i < splitAmt; i++)
		{
			maxValueNode->keys[i] = this->keys[splitAmt + i];
			maxValueNode->nodePtrs[i + 1] = this->nodePtrs[splitAmt + i + 1];
		}
		maxValueNode->nodeCount = 2;
	}

	nodeCount = 2;

	if (evenSplit == false)
	{
		nodeCount--;
		//removing 1 more from minValNode since uneven split.
		this->keys[splitAmt - 1] = numeric_limits<int>::max();
		this->nodePtrs[splitAmt] = nullptr;
	}
		//remove 2 keys and nodes from minValNode.
		for (int i = 0; i < splitAmt; i++)
		{
			this->keys[i + splitAmt] = numeric_limits<int>::max();
			this->nodePtrs[i + splitAmt + 1] = nullptr;
		}	

	return maxValueNode;
}

int IndexNode::minMax()
{
	auto key = this->keys[0];
	this->keys[0] = numeric_limits<int>::max();
	nodeCount--;

	bool evenSplit = false;

	if (nodePtrs[0] == nullptr)
		evenSplit = true;

	for (int i = 0; i <= nodeCount; i++)
	{
		keys[i] = keys[i + 1];
		if (evenSplit)
			nodePtrs[i] = nodePtrs[i + 1]; //only adjust nodeptrs on uneven splits
	}

	for (int i = 0; i < keys.size() - nodeCount; i++)
	{
		keys[nodeCount + i] = numeric_limits<int>::max();
		nodePtrs[nodeCount + 1 + i] = nullptr;
	}

	return key;
}

void IndexNode::TreeDump(int level)
{
	if (level == 0)
		cout << "\nDump of B+Tree\n";

	string indent = "";

	for (int z = 0; z < level; z++)
	{
		indent += "\t";
	}

	cout << indent << "( *, ";
	for (int j = 0; j < nodeCount; j++)
	{
		cout << this->keys[j] << " *, ";
	}

	cout << ")\n";

	for (int i = 0; i <= nodeCount; i++)
	{
		nodePtrs[i]->TreeDump(level + 1);
	}
}

void IndexNode::LeafDump(int level)
{
	if (level == 0)
		cout << "\nLeaves of B+Tree\n";

	nodePtrs[0]->LeafDump(level + 1);
}

int IndexNode::getkey0()
{
	return keys[0];
}