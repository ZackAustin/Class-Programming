#include <array>
#include <iostream>
#include "Tuple.h"

const int MAXKEYS = 4;
const int MINKEYS = MAXKEYS / 2;

#pragma once
class BNode
{
public:
	virtual ~BNode() = 0;
	virtual void* insert(int key, Tuple* data, int treeLevel) = 0;
	virtual void* split(bool evenSplit) = 0;
	virtual int minMax() = 0;
	virtual void TreeDump(int level) = 0;
	virtual void LeafDump(int level) = 0;
	virtual int getkey0() = 0;
};

class DataNode : public BNode
{
	bool leftmostNode;
	int nodeCount;
	std::array<int, MAXKEYS> keys;
	std::array<Tuple*, MAXKEYS> tupleData;
	DataNode* next;
public:
	DataNode(bool leftmost);
	DataNode::DataNode(std::array<int, MAXKEYS / 2> &keyVals, std::array<Tuple*, MAXKEYS / 2> &recVals);
	~DataNode();
	void* insert(int key, Tuple* data, int treeLevel);
	void* split(bool evenSplit);
	int minMax();
	void TreeDump(int level);
	void LeafDump(int level);
	int getkey0();
};

class IndexNode : public BNode
{
	int nodeCount;
	std::array <int, MAXKEYS> keys;
	std::array<BNode*, MAXKEYS + 1> nodePtrs;
public:
	IndexNode();
	IndexNode(BNode* minValNode, BNode* maxValNode, int minmax);
	~IndexNode();
	void* insert(int key, Tuple* data, int treeLevel);
	void* split(bool evenSplit);
	int minMax();
	void TreeDump(int level);
	void LeafDump(int level);
	int getkey0();
};

struct nodeCompare
{
	bool operator() (BNode* t1, BNode* t2)
	{
		int tmp1 = std::numeric_limits<int>::max(), tmp2 = std::numeric_limits<int>::max();
		if (t1 != nullptr)
			tmp1 = t1->getkey0();
		if (t2 != nullptr)
			tmp2 = t2->getkey0();
		return (tmp1 < tmp2);
	}
};