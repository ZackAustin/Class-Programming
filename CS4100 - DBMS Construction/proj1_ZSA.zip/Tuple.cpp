#include "Tuple.h"

Tuple::Tuple(int key) : _key(key)
{
}

Tuple::~Tuple()
{
}
