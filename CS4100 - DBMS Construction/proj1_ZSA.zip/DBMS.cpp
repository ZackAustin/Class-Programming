//	Author:		Zack Austin
//	Project:	B+ Tree Insert for DBMS.
//	Class:		4100 - DBMS
//	Date:		Worked on: 1/30/13

using namespace std;

#include <set>
#include "Tree.h"
#include <random>
#include <assert.h>

const bool ascendingKey = true;
const bool descendingKey = false;
const bool randomKey = false;

int main(int argc, char* argv[])
{
	BNode* root = nullptr;
	set<int> treeSet;

	//Operations Menu
	int menuOption = -1;

	while (menuOption != 0)
	{
		cout << "0 - Exit\n";
		cout << "1 - Create Tree\n";
		cout << "2 - Auto Create Tree\n\n";
		cout << ">  ";
		cin >> menuOption;

		switch (menuOption)
		{
			case 1:
			{
				//create tree by hand, new tree if none exists, if -99 go to main menu aka break.
				if (root == nullptr)
				{
					DataNode* newTree = new DataNode(true);
					root = newTree;
				}
				int theNumbers = -1;
				cout << "Enter Integer, -99 to Main Menu:  ";
				cin >> theNumbers;
				while (theNumbers != -99)
				{
					//while not -99 keep entering keys into tree.

					BNode* curNode = nullptr;

					const bool keyExists = treeSet.find(theNumbers) != treeSet.end();
					if (keyExists == false)
					{
						curNode = reinterpret_cast<BNode*>(root->insert(theNumbers, new Tuple(theNumbers), 0));
						treeSet.insert(theNumbers);
					}

					if (curNode != nullptr)
						root = curNode;

					root->TreeDump(0);
					root->LeafDump(0);

					cout << "Enter Integer, -99 to Main Menu:  ";
					cin >> theNumbers;
				}
				break;
			}
			case 2:
			{
				delete root;
				DataNode* newTree = new DataNode(true);
				root = newTree;
				treeSet.clear();

				cout << "\nEnter # of Keys: ";
				int insertInput = -1;
				cin >> insertInput;

				if (ascendingKey)
				{
					int consecInts = 0;

					for (int i = 0; i < insertInput; i++)
					{
						BNode* curNode = nullptr;

						const bool keyExists = treeSet.find(consecInts) != treeSet.end();
						if (keyExists == false)
						{
							curNode = reinterpret_cast<BNode*>(root->insert(consecInts, new Tuple(consecInts), 0));
							treeSet.insert(consecInts);
							consecInts += 10;
						}

						if (curNode != nullptr)
							root = curNode;
					}
					root->TreeDump(0);
					root->LeafDump(0);
				}
				else if (descendingKey)
				{
					int consecInts = insertInput * 10 - 10;

					for (int i = 0; i < insertInput; i++)
					{
						BNode* curNode = nullptr;

						const bool keyExists = treeSet.find(consecInts) != treeSet.end();
						if (keyExists == false)
						{
							curNode = reinterpret_cast<BNode*>(root->insert(consecInts, new Tuple(consecInts), 0));
							treeSet.insert(consecInts);
							consecInts -= 10;
						}

						if (curNode != nullptr)
							root = curNode;
					}
					root->TreeDump(0);
					root->LeafDump(0);
				}
				else if (randomKey)
				{
					int consecInts = -1;
					random_device rd;

					cout << "Enter # of Times to Run: ";
					int numTimes = -1;
					cin >> numTimes;

					for (int j = 0; j < numTimes; j++)
					{

						delete root;
						DataNode* newTree = new DataNode(true);
						root = newTree;
						treeSet.clear();

						for (int i = 0; i < insertInput; i++)
						{

							consecInts = rd();

							BNode* curNode = nullptr;


							bool keyExists = treeSet.find(consecInts) != treeSet.end();

							while (keyExists != false)
							{
								consecInts = rd();
								keyExists = treeSet.find(consecInts) != treeSet.end();
							}

							if (keyExists == false)
							{
								curNode = reinterpret_cast<BNode*>(root->insert(consecInts, new Tuple(consecInts), 0));
								treeSet.insert(consecInts);
							}

							if (curNode != nullptr)
								root = curNode;
						}

						assert(treeSet.size() == insertInput);
						root->TreeDump(0);
						root->LeafDump(0);
					}
				}
				break;
			}
		}
	}

	delete root;
	return 0;
}